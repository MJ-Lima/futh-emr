@extends('public.layout')

@section('title', 'Doctor Registration')

@section('content')
<section class="futh-auth">
    <div class="futh-container">
        <div class="futh-auth__card futh-auth__card--wide">
            <div class="futh-auth__title"><h1>Private Doctor Registration</h1></div>
            <p class="futh-auth__sub">Register for a verified provider account on the FUTH Lafia network. Our administration will review your application before activation.</p>

            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    Please correct the highlighted fields:
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="post" action="{{ route('provider.doctor.register.store') }}" class="futh-form">
                @csrf

                <div class="futh-form__section">
                    <h3>Personal &amp; contact details</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="title">Title</label>
                            <select id="title" name="title">
                                <option value="">Select</option>
                                @foreach (['Dr', 'Prof', 'Mr', 'Mrs', 'Miss', 'Ms'] as $t)
                                    <option value="{{ $t }}" @selected(old('title')===$t)>{{ $t }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="futh-field">
                            <label for="applicant_name">Full name <span class="req">*</span></label>
                            <input type="text" id="applicant_name" name="applicant_name" value="{{ old('applicant_name') }}" required maxlength="255">
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="email">Email <span class="req">*</span></label>
                            <input type="email" id="email" name="email" value="{{ old('email') }}" required maxlength="255">
                            <span class="help">This will be your provider login.</span>
                        </div>
                        <div class="futh-field">
                            <label for="phone">Phone <span class="req">*</span></label>
                            <input type="tel" id="phone" name="phone" value="{{ old('phone') }}" required maxlength="30">
                        </div>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Professional credentials</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="professional_registration_number">Professional registration number <span class="req">*</span></label>
                            <input type="text" id="professional_registration_number" name="professional_registration_number" value="{{ old('professional_registration_number') }}" required maxlength="100" placeholder="e.g. MDCN Reg. No.">
                        </div>
                        <div class="futh-field">
                            <label for="specialty">Specialty <span class="req">*</span></label>
                            <select id="specialty" name="specialty" required>
                                <option value="">Select specialty</option>
                                @foreach (['General Practice', 'Internal Medicine', 'Paediatrics', 'Obstetrics & Gynaecology', 'Surgery', 'Orthopaedics', 'Psychiatry', 'Ophthalmology', 'ENT', 'Dermatology', 'Radiology', 'Anaesthesia', 'Emergency Medicine', 'Family Medicine', 'Public Health', 'Pathology', 'Other'] as $s)
                                    <option value="{{ $s }}" @selected(old('specialty')===$s)>{{ $s }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="qualification">Highest qualification <span class="req">*</span></label>
                            <input type="text" id="qualification" name="qualification" value="{{ old('qualification') }}" required maxlength="255" placeholder="e.g. MBBS, FWACS">
                        </div>
                        <div class="futh-field">
                            <label for="years_of_experience">Years of experience</label>
                            <input type="number" id="years_of_experience" name="years_of_experience" value="{{ old('years_of_experience') }}" min="0" max="80">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="bio">Short professional bio</label>
                        <textarea id="bio" name="bio" rows="3" maxlength="2000">{{ old('bio') }}</textarea>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Services offered</h3>
                    <p class="help" style="margin-bottom: 0.5rem;">Select all services you provide.</p>
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.5rem;">
                        @foreach (['Outpatient Consultation', 'Telemedicine', 'Home Visits', 'Antenatal Care', 'Child Welfare', 'Minor Procedures', 'Vaccination', 'Chronic Disease Management', 'Mental Health', 'Lab Referral', 'Imaging Referral', 'Inpatient Admission Referral'] as $service)
                        <label style="display:flex; align-items:center; gap:0.5rem; font-size:0.9rem; padding: 0.4rem 0.65rem; border: 1px solid var(--futh-border); border-radius: 8px;">
                            <input type="checkbox" name="services_offered[]" value="{{ $service }}" @checked(in_array($service, old('services_offered', [])))>
                            {{ $service }}
                        </label>
                        @endforeach
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Account security</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="password">Create password <span class="req">*</span></label>
                            <input type="password" id="password" name="password" required minlength="8">
                            <span class="help">Minimum 8 characters.</span>
                        </div>
                        <div class="futh-field">
                            <label for="password_confirmation">Confirm password <span class="req">*</span></label>
                            <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">
                        </div>
                    </div>
                </div>

                <div style="display:flex; gap:0.75rem; justify-content:flex-end;">
                    <a href="{{ route('provider.index') }}" class="futh-btn futh-btn--ghost">Back</a>
                    <button type="submit" class="futh-btn futh-btn--primary futh-btn--lg">Submit application</button>
                </div>
            </form>
        </div>
    </div>
</section>
@endsection
