@extends('public.layout')

@section('title', 'Forgot Password')

@section('content')
<section class="futh-auth">
    <div class="futh-container">
        <div class="futh-auth__card">
            <div class="futh-auth__title"><h1>Reset your password</h1></div>
            <p class="futh-auth__sub">@if($userType === 'patient') Enter your patient portal email below and we'll send you a reset link. @else Enter your staff email below and we'll send you a reset link. @endif</p>

            @if (session('status'))
                <div class="futh-alert futh-alert--success">{{ session('status') }}</div>
            @endif

            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
                </div>
            @endif

            <form method="post" action="{{ route($routeBase . '.email') }}" class="futh-form">
                @csrf
                <input type="hidden" name="guard" value="{{ $guard }}">
                <div class="futh-field">
                    <label for="email">Email address <span class="req">*</span></label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus>
                </div>
                <button type="submit" class="futh-btn futh-btn--primary futh-btn--block futh-btn--lg">Send reset link</button>
            </form>

            <div class="futh-center futh-mt-3" style="font-size:0.9rem;">
                @if($userType === 'patient')
                    <a href="{{ route('portal.login') }}">Back to patient sign in</a>
                @else
                    <a href="{{ route('filament.admin.auth.login') }}">Back to staff login</a>
                @endif
            </div>
        </div>
    </div>
</section>
@endsection
