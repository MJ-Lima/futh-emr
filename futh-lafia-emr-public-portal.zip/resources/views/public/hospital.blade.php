@extends('public.layout')

@section('title', $hospital->name)

@section('content')
<section class="futh-hero" style="padding: 3rem 0 3.5rem;">
    <div class="futh-container futh-hero__inner">
        <span class="futh-eyebrow" style="background: rgba(255,255,255,0.14); color: var(--futh-gold-light);">{{ ucfirst($hospital->type) }} &middot; {{ $hospital->code }}</span>
        <h1>{{ $hospital->name }}</h1>
        @if ($hospital->tagline)
        <p class="futh-hero__lead">{{ $hospital->tagline }}</p>
        @endif
        <div class="futh-hero__cta">
            @if ($hospital->accepts_online_registration)
            <a href="{{ route('public.patient.register', $hospital) }}" class="futh-btn futh-btn--gold">Register as Patient</a>
            @endif
            <a href="{{ route('public.directory') }}" class="futh-btn futh-btn--outline" style="color:#fff; border-color:rgba(255,255,255,0.7);">Back to directory</a>
        </div>
    </div>
</section>

<section class="futh-section">
    <div class="futh-container">
        <div style="display:grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
            <div>
                @if ($hospital->description)
                <div class="futh-panel">
                    <div class="futh-panel__head"><h3>About this hospital</h3></div>
                    <div class="futh-panel__body">
                        <p>{{ $hospital->description }}</p>
                    </div>
                </div>
                @endif

                @if (is_array($hospital->services) && count($hospital->services))
                <div class="futh-panel">
                    <div class="futh-panel__head"><h3>Services offered</h3></div>
                    <div class="futh-panel__body">
                        <div style="display:flex; flex-wrap:wrap; gap:0.5rem;">
                            @foreach ($hospital->services as $service)
                                <span class="futh-badge futh-badge--green" style="padding: 0.4rem 0.85rem; font-size: 0.85rem;">{{ $service }}</span>
                            @endforeach
                        </div>
                    </div>
                </div>
                @endif

                @if ($hospital->clinics->count())
                <div class="futh-panel">
                    <div class="futh-panel__head"><h3>Clinics ({{ $hospital->clinics->count() }})</h3></div>
                    <div class="futh-panel__body--flush futh-panel__body">
                        <table class="futh-table">
                            <thead><tr><th>Clinic</th><th>Code</th></tr></thead>
                            <tbody>
                                @foreach ($hospital->clinics as $clinic)
                                <tr><td>{{ $clinic->name }}</td><td>{{ $clinic->code ?: '&mdash;' }}</td></tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                @endif

                @if ($hospital->operating_hours)
                <div class="futh-panel">
                    <div class="futh-panel__head"><h3>Operating hours</h3></div>
                    <div class="futh-panel__body">
                        <dl class="futh-detail">
                            @foreach ((array) $hospital->operating_hours as $day => $hours)
                                <dt>{{ ucfirst($day) }}</dt>
                                <dd>{{ is_array($hours) ? ($hours['closed'] ?? implode(' &ndash; ', $hours)) : $hours }}</dd>
                            @endforeach
                        </dl>
                    </div>
                </div>
                @endif
            </div>

            <aside>
                <div class="futh-panel">
                    <div class="futh-panel__head"><h3>Contact</h3></div>
                    <div class="futh-panel__body">
                        <div style="display:flex; flex-direction:column; gap:0.75rem; font-size:0.92rem;">
                            @if ($hospital->phone_main)
                            <div><i>&#9742;</i> <strong>Main:</strong> {{ $hospital->phone_main }}</div>
                            @endif
                            @if ($hospital->phone_alt)
                            <div><i>&#9742;</i> <strong>Alt:</strong> {{ $hospital->phone_alt }}</div>
                            @endif
                            @if ($hospital->email)
                            <div><i>&#9993;</i> <a href="mailto:{{ $hospital->email }}">{{ $hospital->email }}</a></div>
                            @endif
                            @if ($hospital->website)
                            <div><i>&#127760;</i> <a href="{{ $hospital->website }}" target="_blank" rel="noopener">{{ $hospital->website }}</a></div>
                            @endif
                            <div><i>&#128205;</i> {{ $hospital->full_address }}</div>
                        </div>
                    </div>
                </div>

                <div class="futh-panel">
                    <div class="futh-panel__head"><h3>Quick actions</h3></div>
                    <div class="futh-panel__body" style="display:flex; flex-direction:column; gap:0.6rem;">
                        @if ($hospital->accepts_online_registration)
                        <a href="{{ route('public.patient.register', $hospital) }}" class="futh-btn futh-btn--primary futh-btn--block">Register as Patient</a>
                        @endif
                        @if (Auth::guard('patient_portal')->check())
                        <a href="{{ route('portal.appointments.create', ['hospital_id' => $hospital->id]) }}" class="futh-btn futh-btn--ghost futh-btn--block">Book Appointment</a>
                        <a href="{{ route('portal.messages.create') }}" class="futh-btn futh-btn--ghost futh-btn--block">Message this hospital</a>
                        @else
                        <a href="{{ route('portal.login') }}" class="futh-btn futh-btn--ghost futh-btn--block">Sign in to book appointment</a>
                        @endif
                    </div>
                </div>
            </aside>
        </div>
    </div>
</section>
@endsection
