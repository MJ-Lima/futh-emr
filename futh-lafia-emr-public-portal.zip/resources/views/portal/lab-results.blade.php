@extends('portal.layout')

@section('title', 'Lab Results')

@section('content')
<div class="futh-panel">
    <div class="futh-panel__head"><h3>Laboratory Orders &amp; Results</h3></div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($labOrders) > 0)
        @foreach ($labOrders as $order)
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--futh-border);">
            <div class="futh-flex futh-flex--between futh-flex--center futh-mb-1">
                <div>
                    <strong>{{ $order->order_number }}</strong>
                    <span class="futh-muted" style="font-size:0.85rem;">&middot; {{ \Carbon\Carbon::parse($order->ordered_at)->format('d M Y, H:i') }}</span>
                </div>
                <span class="futh-badge futh-badge--{{ in_array($order->status, ['Verified','Completed']) ? 'green' : ($order->status === 'Cancelled' ? 'red' : 'amber') }}">{{ $order->status }}</span>
            </div>
            @if ($order->items->count())
            <table class="futh-table" style="font-size:0.85rem;">
                <thead><tr><th>Test</th><th>Result</th><th>Unit</th><th>Reference</th><th>Flag</th></tr></thead>
                <tbody>
                    @foreach ($order->items as $item)
                        @foreach ($item->results as $result)
                        <tr>
                            <td>{{ $item->test_name }}</td>
                            <td><strong>{{ $result->value }}</strong></td>
                            <td>{{ $result->unit }}</td>
                            <td>{{ $result->reference_range }}</td>
                            <td>
                                @if ($result->flag === 'Normal')
                                    <span class="futh-badge futh-badge--green">{{ $result->flag }}</span>
                                @elseif (in_array($result->flag, ['Critical Low','Critical High']))
                                    <span class="futh-badge futh-badge--red">{{ $result->flag }}</span>
                                @else
                                    <span class="futh-badge futh-badge--amber">{{ $result->flag }}</span>
                                @endif
                            </td>
                        </tr>
                        @endforeach
                        @if ($item->results->isEmpty())
                        <tr><td>{{ $item->test_name }}</td><td colspan="4" class="futh-muted">Result pending</td></tr>
                        @endif
                    @endforeach
                </tbody>
            </table>
            @else
            <p class="futh-muted" style="font-size:0.85rem;">No tests in this order.</p>
            @endif
        </div>
        @endforeach
        @else
        <div class="futh-table__empty">No lab orders yet. Your results will appear here once they are released by the laboratory.</div>
        @endif
    </div>
</div>
<div class="futh-center">{{ $labOrders->links() ?? '' }}</div>
@endsection
