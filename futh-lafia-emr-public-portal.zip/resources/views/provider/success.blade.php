@extends('public.layout')

@section('title', 'Application Submitted')

@section('content')
<section class="futh-section">
    <div class="futh-container futh-container--narrow">
        <div class="futh-auth__card">
            <div class="futh-center">
                <div style="width:64px; height:64px; border-radius:50%; background: var(--futh-green-50); color: var(--futh-green); display:grid; place-items:center; margin: 0 auto 1rem; font-size: 2rem;">&#10003;</div>
                <h1>Application received</h1>
                <p class="futh-muted">Thank you, {{ $application->display_name }}. Your {{ $application->account_type }} application has been submitted and is now pending review.</p>
            </div>

            <div class="futh-panel futh-mt-3">
                <div class="futh-panel__body">
                    <dl class="futh-detail">
                        <dt>Application number</dt><dd><strong>{{ $application->application_number }}</strong></dd>
                        <dt>Applicant</dt><dd>{{ $application->display_name }}</dd>
                        <dt>Email</dt><dd>{{ $application->email }}</dd>
                        <dt>Type</dt><dd><span class="futh-badge futh-badge--green">{{ ucfirst($application->account_type) }}</span></dd>
                        <dt>Status</dt><dd><span class="futh-badge futh-badge--amber">Pending review</span></dd>
                    </dl>
                </div>
            </div>

            <div class="futh-alert futh-alert--info futh-mt-2">
                Our administration will verify your credentials and review your application. You will receive an email at <strong>{{ $application->email }}</strong> once your account has been approved.
            </div>

            <div class="futh-center futh-mt-3" style="display:flex; gap:0.75rem; justify-content:center;">
                <a href="{{ route('public.landing') }}" class="futh-btn futh-btn--primary">Back to home</a>
                <a href="{{ route('provider.index') }}" class="futh-btn futh-btn--ghost">Provider home</a>
            </div>
        </div>
    </div>
</section>
@endsection
