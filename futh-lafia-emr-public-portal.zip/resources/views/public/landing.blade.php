@extends('public.layout')

@section('title', 'Welcome')

@section('content')
<!-- HERO -->
<section class="futh-hero">
    <div class="futh-container futh-hero__inner">
        <span class="futh-eyebrow" style="background: rgba(255,255,255,0.14); color: var(--futh-gold-light);">Federal University Teaching Hospital, Lafia</span>
        <h1>Compassionate care for <span class="gold">every Nigerian</span>, across our network of hospitals.</h1>
        <p class="futh-hero__lead">
            Register as a patient in minutes, find a hospital near you, book appointments, and view your medical records &mdash; all in one secure portal.
        </p>
        <div class="futh-hero__cta">
            <a href="{{ route('public.patient.register') }}" class="futh-btn futh-btn--gold futh-btn--lg">Register as Patient</a>
            <a href="{{ route('public.directory') }}" class="futh-btn futh-btn--outline futh-btn--lg" style="color:#fff; border-color:rgba(255,255,255,0.7);">Find a Hospital</a>
        </div>

        <div class="futh-hero__stats">
            <div class="futh-hero__stat">
                <strong>{{ $stats['hospitals'] ?: '6' }}+</strong>
                <span>Network Hospitals</span>
            </div>
            <div class="futh-hero__stat">
                <strong>{{ $stats['states'] ?: '4' }}+</strong>
                <span>States Served</span>
            </div>
            <div class="futh-hero__stat">
                <strong>{{ $stats['specialties'] }}</strong>
                <span>Clinical Specialties</span>
            </div>
            <div class="futh-hero__stat">
                <strong>{{ $stats['years'] }}+</strong>
                <span>Years of Service</span>
            </div>
        </div>
    </div>
</section>

<!-- SERVICES -->
<section class="futh-section">
    <div class="futh-container">
        <div class="futh-section__head">
            <span class="futh-eyebrow">What You Can Do</span>
            <h2>Your health, in your hands</h2>
            <p>One portal connects you to every hospital in the FUTH Lafia network &mdash; from Nasarawa to neighbouring states.</p>
        </div>
        <div class="futh-services-grid">
            <div class="futh-service">
                <div class="futh-service__icon">&#129657;</div>
                <h3>Register as a Patient</h3>
                <p>Create your record at any of our network hospitals &mdash; get a hospital number instantly.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#128197;</div>
                <h3>Book Appointments</h3>
                <p>Pick a clinic, choose an available slot, and confirm &mdash; no queues, no phone calls.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#128202;</div>
                <h3>View Lab Results</h3>
                <p>See verified laboratory and radiology results as soon as they are released.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#128138;</div>
                <h3>Track Prescriptions</h3>
                <p>Review your current medications, dosages, and dispensing status in one place.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#128176;</div>
                <h3>Pay Invoices</h3>
                <p>View outstanding bills, payment history, and download official receipts.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#128172;</div>
                <h3>Message Your Hospital</h3>
                <p>Secure two-way messaging with the care team for non-emergency questions.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#127973;</div>
                <h3>Hospital Directory</h3>
                <p>Browse all network hospitals with contacts, services, and operating hours.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#129518;</div>
                <h3>For Providers</h3>
                <p>Private doctors and external hospitals can register to join our network.</p>
            </div>
        </div>
    </div>
</section>

<!-- HOSPITAL DIRECTORY PREVIEW -->
<section class="futh-section futh-section--soft">
    <div class="futh-container">
        <div class="futh-section__head">
            <span class="futh-eyebrow">Our Network</span>
            <h2>Hospitals near you</h2>
            <p>A growing network of teaching, general, and specialist facilities across Nigeria.</p>
        </div>
        @if ($hospitals->count())
        <div class="futh-hospital-grid">
            @foreach ($hospitals as $hospital)
                <div class="futh-card">
                    <div class="futh-card__cover">
                        @if ($hospital->cover_url)
                            <img src="{{ $hospital->cover_url }}" alt="{{ $hospital->name }}">
                        @else
                            <span style="font-family: var(--futh-font-serif); font-size: 2rem;">{{ strtoupper(Str::substr($hospital->name, 0, 1)) }}</span>
                        @endif
                        <span class="futh-card__badge">{{ ucfirst($hospital->type) }}</span>
                    </div>
                    <div class="futh-card__body">
                        <h3 class="futh-card__title"><a href="{{ route('public.hospital', $hospital) }}">{{ $hospital->name }}</a></h3>
                        <p class="futh-card__sub">{{ $hospital->tagline }}</p>
                        <div class="futh-card__meta">
                            <span><i>&#128205;</i> {{ $hospital->city ? $hospital->city . ', ' . $hospital->state : 'Lafia, Nasarawa' }}</span>
                            <span><i>&#9742;</i> {{ $hospital->phone_main ?: '+234 803 000 0001' }}</span>
                        </div>
                    </div>
                    <div class="futh-card__footer">
                        <a href="{{ route('public.hospital', $hospital) }}" class="futh-btn futh-btn--ghost futh-btn--sm">View profile</a>
                        @if ($hospital->accepts_online_registration)
                        <a href="{{ route('public.patient.register', $hospital) }}" class="futh-btn futh-btn--primary futh-btn--sm">Register here</a>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
        @else
        <p class="futh-center futh-muted">Hospital directory will appear here once seeded.</p>
        @endif
        <div class="futh-center futh-mt-3">
            <a href="{{ route('public.directory') }}" class="futh-btn futh-btn--outline">Browse all hospitals</a>
        </div>
    </div>
</section>

<!-- CTA BAND -->
<section class="futh-cta-band">
    <div class="futh-container">
        <h2>Are you a private doctor or running a hospital?</h2>
        <p>Join the FUTH Lafia network. Get a verified provider account, refer patients, and collaborate with our care teams.</p>
        <a href="{{ route('provider.index') }}" class="futh-btn futh-btn--gold futh-btn--lg">Register as a Provider</a>
    </div>
</section>
@endsection
