@extends('public.layout')

@section('title', 'Set New Password')

@section('content')
<section class="futh-auth">
    <div class="futh-container">
        <div class="futh-auth__card">
            <div class="futh-auth__title"><h1>Set a new password</h1></div>
            <p class="futh-auth__sub">@if($userType === 'patient') Choose a new password for your patient portal account. @else Choose a new password for your staff account. @endif</p>

            @if (session('status'))
                <div class="futh-alert futh-alert--success">{{ session('status') }}</div>
            @endif

            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
                </div>
            @endif

            <form method="post" action="{{ route($routeBase . '.update') }}" class="futh-form">
                @csrf
                <input type="hidden" name="guard" value="{{ $guard }}">
                <input type="hidden" name="token" value="{{ $token }}">
                <div class="futh-field">
                    <label for="email">Email address <span class="req">*</span></label>
                    <input type="email" id="email" name="email" value="{{ $email ?? old('email') }}" required autofocus>
                </div>
                <div class="futh-field">
                    <label for="password">New password <span class="req">*</span></label>
                    <input type="password" id="password" name="password" required minlength="8">
                    <span class="help">Minimum 8 characters.</span>
                </div>
                <div class="futh-field">
                    <label for="password_confirmation">Confirm new password <span class="req">*</span></label>
                    <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">
                </div>
                <button type="submit" class="futh-btn futh-btn--primary futh-btn--block futh-btn--lg">Reset password</button>
            </form>

            <div class="futh-center futh-mt-3" style="font-size:0.9rem;">
                @if($userType === 'patient')
                    <a href="{{ route('portal.login') }}">Back to patient sign in</a>
                @else
                    <a href="{{ route('filament.admin.auth.login') }}">Back to staff login</a>
                @endif
            </div>
        </div>
    </div>
</section>
@endsection
