@extends('public.layout')

@section('title', 'Hospital Directory')

@section('content')
<section class="futh-section">
    <div class="futh-container">
        <div class="futh-section__head">
            <span class="futh-eyebrow">Hospital Directory</span>
            <h2>Find a hospital in our network</h2>
            <p>Browse all network hospitals, filter by state or facility type, and register as a patient at the one nearest you.</p>
        </div>

        <form method="get" class="futh-form__section" style="display:grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 1rem; align-items: end;">
            <div class="futh-field">
                <label for="q">Search</label>
                <input type="text" id="q" name="q" value="{{ request('q') }}" placeholder="Hospital name, city or tagline">
            </div>
            <div class="futh-field">
                <label for="state">State</label>
                <select id="state" name="state">
                    <option value="">All states</option>
                    @foreach ($states as $state)
                        <option value="{{ $state }}" @selected(request('state') === $state)>{{ $state }}</option>
                    @endforeach
                </select>
            </div>
            <div class="futh-field">
                <label for="type">Facility type</label>
                <select id="type" name="type">
                    <option value="">All types</option>
                    @foreach ($types as $type)
                        <option value="{{ $type }}" @selected(request('type') === $type)>{{ ucfirst($type) }}</option>
                    @endforeach
                </select>
            </div>
            <button class="futh-btn futh-btn--primary" type="submit">Search</button>
        </form>

        @if ($hospitals->count())
        <div class="futh-hospital-grid futh-mt-3">
            @foreach ($hospitals as $hospital)
                <div class="futh-card">
                    <div class="futh-card__cover">
                        @if ($hospital->cover_url)
                            <img src="{{ $hospital->cover_url }}" alt="{{ $hospital->name }}">
                        @else
                            <span style="font-family: var(--futh-font-serif); font-size: 2rem; color:#fff;">{{ strtoupper(Str::substr($hospital->name, 0, 1)) }}</span>
                        @endif
                        <span class="futh-card__badge">{{ ucfirst($hospital->type) }}</span>
                    </div>
                    <div class="futh-card__body">
                        <h3 class="futh-card__title"><a href="{{ route('public.hospital', $hospital) }}">{{ $hospital->name }}</a></h3>
                        <p class="futh-card__sub">{{ $hospital->tagline }}</p>
                        <div class="futh-card__meta">
                            <span><i>&#128205;</i> {{ $hospital->city ? $hospital->city . ', ' . $hospital->state : 'Nigeria' }}</span>
                            <span><i>&#9742;</i> {{ $hospital->phone_main ?: '&mdash;' }}</span>
                            @if ($hospital->email)
                            <span><i>&#9993;</i> {{ $hospital->email }}</span>
                            @endif
                        </div>
                        @if (is_array($hospital->services) && count($hospital->services))
                        <div class="futh-mt-2" style="display:flex; flex-wrap:wrap; gap:0.35rem;">
                            @foreach (array_slice($hospital->services, 0, 4) as $service)
                                <span class="futh-badge futh-badge--green">{{ $service }}</span>
                            @endforeach
                            @if (count($hospital->services) > 4)
                                <span class="futh-badge futh-badge--gray">+{{ count($hospital->services) - 4 }} more</span>
                            @endif
                        </div>
                        @endif
                    </div>
                    <div class="futh-card__footer">
                        <a href="{{ route('public.hospital', $hospital) }}" class="futh-btn futh-btn--ghost futh-btn--sm">View profile</a>
                        @if ($hospital->accepts_online_registration)
                        <a href="{{ route('public.patient.register', $hospital) }}" class="futh-btn futh-btn--primary futh-btn--sm">Register</a>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
        @else
        <div class="futh-center futh-mt-3">
            <p class="futh-muted" style="font-size: 1.05rem;">No hospitals match your search. Try clearing the filters.</p>
        </div>
        @endif

        <div class="futh-center futh-mt-3">
            {{ $hospitals->links() }}
        </div>
    </div>
</section>
@endsection
