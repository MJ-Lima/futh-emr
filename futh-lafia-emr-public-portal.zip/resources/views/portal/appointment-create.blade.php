@extends('portal.layout')

@section('title', 'Book Appointment')

@section('head')
<style>
.futh-slot-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 0.5rem; margin-top: 0.75rem; }
.futh-slot { padding: 0.65rem; border: 1.5px solid var(--futh-border); border-radius: 10px; text-align: center; cursor: pointer; background:#fff; transition: all .15s; font-size: 0.9rem; }
.futh-slot:hover { border-color: var(--futh-green-400); background: var(--futh-green-50); }
.futh-slot--selected { border-color: var(--futh-green); background: var(--futh-green); color: #fff; }
.futh-slot--unavailable { opacity: .4; cursor: not-allowed; text-decoration: line-through; }
</style>
@endsection

@section('content')
<div class="futh-auth__card futh-auth__card--wide" style="max-width:760px; margin: 0 auto;">
    <div class="futh-auth__title"><h1>Book an Appointment</h1></div>
    <p class="futh-auth__sub">Choose a hospital and clinic, pick an available slot, and tell us why you are visiting.</p>

    @if ($errors->any())
        <div class="futh-alert futh-alert--danger">
            @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
        </div>
    @endif

    <form id="bookingForm" method="post" action="{{ route('portal.appointments.store') }}" class="futh-form">
        @csrf
        <div class="futh-form__section">
            <h3>1. Choose hospital &amp; clinic</h3>
            <div class="futh-field">
                <label for="hospital_id">Hospital</label>
                <select id="hospital_id" name="hospital_id" required>
                    @foreach ($hospitals as $h)
                    <option value="{{ $h->id }}" @selected($selectedHospital && $selectedHospital->id === $h->id)>{{ $h->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="futh-field">
                <label for="clinic_id">Clinic</label>
                <select id="clinic_id" name="clinic_id" required>
                    @foreach ($clinics as $c)
                    <option value="{{ $c->id }}">{{ $c->name }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="futh-form__section">
            <h3>2. Pick a date</h3>
            <div class="futh-field">
                <label for="date">Appointment date</label>
                <input type="date" id="date" name="date" min="{{ now()->toDateString() }}" required>
            </div>
            <div id="slots-container" class="futh-slot-grid" style="display:none;">
                <p class="futh-muted">Pick a date to see available time slots.</p>
            </div>
            <input type="hidden" id="slot_id" name="slot_id" required>
        </div>

        <div class="futh-form__section">
            <h3>3. Visit details</h3>
            <div class="futh-grid-2">
                <div class="futh-field">
                    <label for="visit_type">Visit type</label>
                    <select id="visit_type" name="visit_type" required>
                        <option value="New">New visit</option>
                        <option value="Follow-up">Follow-up</option>
                        <option value="Review">Review</option>
                        <option value="Telemedicine">Telemedicine</option>
                    </select>
                </div>
                <div class="futh-field">
                    <label for="appointment_type_id">Appointment type</label>
                    <select id="appointment_type_id" name="appointment_type_id">
                        <option value="">Any</option>
                        @foreach ($types as $t)
                        <option value="{{ $t->id }}">{{ $t->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="futh-field">
                <label for="reason_for_visit">Reason for visit <span class="req">*</span></label>
                <textarea id="reason_for_visit" name="reason_for_visit" rows="3" required maxlength="1000" placeholder="Briefly describe your symptoms or reason for the visit."></textarea>
            </div>
        </div>

        <div style="display:flex; gap:0.75rem; justify-content:flex-end;">
            <a href="{{ route('portal.appointments') }}" class="futh-btn futh-btn--ghost">Cancel</a>
            <button type="submit" class="futh-btn futh-btn--primary futh-btn--lg">Confirm booking</button>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
(function(){
    var hospital = document.getElementById('hospital_id');
    var clinic = document.getElementById('clinic_id');
    var date = document.getElementById('date');
    var slotsContainer = document.getElementById('slots-container');
    var slotId = document.getElementById('slot_id');
    var csrf = document.querySelector('meta[name="csrf-token"]');

    function reloadClinics(){
        var hid = hospital.value;
        fetch("{{ route('public.ajax.clinics') }}?hospital_id=" + encodeURIComponent(hid), {headers: {'Accept':'application/json'}})
            .then(function(r){return r.json();})
            .then(function(data){
                clinic.innerHTML = '';
                (data.clinics || []).forEach(function(c){
                    var o = document.createElement('option');
                    o.value = c.id; o.textContent = c.name;
                    clinic.appendChild(o);
                });
                loadSlots();
            });
    }
    function loadSlots(){
        var hid = hospital.value, cid = clinic.value, d = date.value;
        if (!hid || !cid || !d) { slotsContainer.style.display = 'none'; return; }
        slotsContainer.style.display = 'grid';
        slotsContainer.innerHTML = '<p class="futh-muted">Loading slots...</p>';
        slotId.value = '';
        fetch("{{ route('portal.appointments.slots') }}?hospital_id=" + hid + "&clinic_id=" + cid + "&date=" + d, {headers: {'Accept':'application/json'}})
            .then(function(r){return r.json();})
            .then(function(data){
                slotsContainer.innerHTML = '';
                if (!data.slots || !data.slots.length) {
                    slotsContainer.innerHTML = '<p class="futh-muted">No slots available on this date. Try another date.</p>';
                    return;
                }
                data.slots.forEach(function(s){
                    var el = document.createElement('div');
                    el.className = 'futh-slot';
                    el.textContent = s.start_time + ' - ' + s.end_time;
                    el.dataset.slotId = s.id;
                    el.addEventListener('click', function(){
                        document.querySelectorAll('.futh-slot').forEach(function(x){ x.classList.remove('futh-slot--selected'); });
                        el.classList.add('futh-slot--selected');
                        slotId.value = s.id;
                    });
                    slotsContainer.appendChild(el);
                });
            });
    }
    hospital.addEventListener('change', reloadClinics);
    clinic.addEventListener('change', loadSlots);
    date.addEventListener('change', loadSlots);
})();
</script>
@endpush
