<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'FUTH Lafia EMR') &middot; Federal University Teaching Hospital</title>
    <meta name="description" content="@yield('meta_description', 'Federal University Teaching Hospital, Lafia — patient portal, hospital directory, and provider registration.')">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/futh-public-portal.css') }}">
    @yield('head')
</head>
<body class="futh-public">
    @if (! isset($hideTopbar))
    <div class="futh-topbar">
        <div class="futh-container futh-topbar__inner">
            <div class="futh-topbar__contact">
                <span>&#9742; +234 803 000 0001</span>
                <span>&#9993; care@futhlafia.gov.ng</span>
                <span>&#9737; Lafia, Nasarawa State, Nigeria</span>
            </div>
            <div>
                @if (Auth::guard('patient_portal')->check())
                    <a href="{{ route('portal.dashboard') }}">My Portal</a> &middot;
                    <a href="{{ route('portal.logout') }}">Sign Out</a>
                @else
                    <a href="{{ route('portal.login') }}">Patient Sign In</a> &middot;
                    <a href="{{ route('filament.admin.auth.login') }}">Staff Login</a>
                @endif
            </div>
        </div>
    </div>
    @endif

    <nav class="futh-navbar">
        <div class="futh-container futh-navbar__inner">
            <a href="{{ route('public.landing') }}" class="futh-brand" aria-label="FUTH Lafia home">
                <span class="futh-brand__logo">FL</span>
                <span class="futh-brand__text">
                    <span class="futh-brand__name">FUTH Lafia EMR</span>
                    <span class="futh-brand__sub">Federal Teaching Hospital</span>
                </span>
            </a>
            <button class="futh-nav__toggle" onclick="document.getElementById('futh-nav').classList.toggle('futh-nav--open'); document.getElementById('futh-nav-cta').classList.toggle('futh-nav__cta--open');" aria-label="Toggle menu">
                <span></span><span></span><span></span>
            </button>
            <div class="futh-nav" id="futh-nav">
                <a href="{{ route('public.landing') }}" class="@if (request()->routeIs('public.landing')) futh-nav__active @endif">Home</a>
                <a href="{{ route('public.directory') }}" class="@if (request()->routeIs('public.directory')) futh-nav__active @endif">Find a Hospital</a>
                <a href="{{ route('public.patient.register') }}" class="@if (request()->routeIs('public.patient.register')) futh-nav__active @endif">Register as Patient</a>
                <a href="{{ route('public.feedback.create') }}" class="@if (request()->routeIs('public.feedback.*')) futh-nav__active @endif">Feedback</a>
                <a href="{{ route('provider.index') }}" class="@if (request()->routeIs('provider.index')) futh-nav__active @endif">For Providers</a>
                <a href="{{ route('public.about') }}" class="@if (request()->routeIs('public.about')) futh-nav__active @endif">About</a>
            </div>
            <div class="futh-nav__cta" id="futh-nav-cta">
                <a href="{{ route('portal.login') }}" class="futh-btn futh-btn--ghost futh-btn--sm">Patient Sign In</a>
                <a href="{{ route('public.patient.register') }}" class="futh-btn futh-btn--primary futh-btn--sm">Register Now</a>
            </div>
        </div>
    </nav>

    @if (session('success'))
        <div class="futh-container" style="margin-top: 1.25rem;">
            <div class="futh-alert futh-alert--success">{{ session('success') }}</div>
        </div>
    @endif
    @if (session('danger') || session('error'))
        <div class="futh-container" style="margin-top: 1.25rem;">
            <div class="futh-alert futh-alert--danger">{{ session('danger') ?? session('error') }}</div>
        </div>
    @endif
    @if (session('warning'))
        <div class="futh-container" style="margin-top: 1.25rem;">
            <div class="futh-alert futh-alert--warning">{{ session('warning') }}</div>
        </div>
    @endif
    @if (session('info'))
        <div class="futh-container" style="margin-top: 1.25rem;">
            <div class="futh-alert futh-alert--info">{{ session('info') }}</div>
        </div>
    @endif

    @yield('content')

    <footer class="futh-footer">
        <div class="futh-container">
            <div class="futh-footer__grid">
                <div class="futh-footer__brand">
                    <div class="futh-brand">
                        <span class="futh-brand__logo">FL</span>
                        <span class="futh-brand__text">
                            <span class="futh-brand__name">FUTH Lafia EMR</span>
                            <span class="futh-brand__sub">Federal Teaching Hospital</span>
                        </span>
                    </div>
                    <p>Federal University Teaching Hospital, Lafia — delivering compassionate, world-class healthcare to Nasarawa State and beyond since 2007.</p>
                </div>
                <div>
                    <h4>Patients</h4>
                    <div class="futh-footer__links">
                        <a href="{{ route('public.patient.register') }}">Register as Patient</a>
                        <a href="{{ route('portal.login') }}">Patient Sign In</a>
                        <a href="{{ route('public.directory') }}">Find a Hospital</a>
                        <a href="{{ route('public.feedback.create') }}">Give Feedback</a>
                        @if (Auth::guard('patient_portal')->check())
                        <a href="{{ route('portal.appointments.create') }}">Book Appointment</a>
                        @endif
                    </div>
                </div>
                <div>
                    <h4>Providers</h4>
                    <div class="futh-footer__links">
                        <a href="{{ route('provider.doctor.register') }}">Doctor Registration</a>
                        <a href="{{ route('provider.hospital.register') }}">Hospital / Clinic Registration</a>
                        <a href="{{ route('filament.admin.auth.login') }}">Staff Login</a>
                    </div>
                </div>
                <div>
                    <h4>Get in Touch</h4>
                    <div class="futh-footer__links">
                        <a href="tel:+2348030000001">+234 803 000 0001</a>
                        <a href="mailto:care@futhlafia.gov.ng">care@futhlafia.gov.ng</a>
                        <span>Lafia, Nasarawa State, Nigeria</span>
                    </div>
                </div>
            </div>
            <div class="futh-footer__bottom">
                <span>&copy; {{ date('Y') }} Federal University Teaching Hospital, Lafia. All rights reserved.</span>
                <span>v2.1 &middot; Public Portal</span>
            </div>
        </div>
    </footer>

    @yield('scripts')
</body>
</html>
