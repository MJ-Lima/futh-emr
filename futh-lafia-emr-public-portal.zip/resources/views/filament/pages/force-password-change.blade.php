<x-filament-panels::page>
    <div class="flex items-center justify-center min-h-[60vh]">
        <div class="w-full max-w-md">
            @if (session('warning'))
                <x-filament::notification
                    icon="heroicon-o-exclamation-triangle"
                    color="warning"
                >
                    {{ session('warning') }}
                </x-filament::notification>
            @endif

            <div class="mt-6">
                <form wire:submit="changePassword">
                    <div class="space-y-5">
                        <div>
                            <h2 class="text-xl font-bold text-gray-800">Change Your Password</h2>
                            <p class="text-sm text-gray-500 mt-1">
                                Your account was created with a temporary password. Please set a new password to continue.
                            </p>
                        </div>

                        <x-filament::field
                            label="Current password"
                            required
                        >
                            <x-filament::input
                                type="password"
                                wire:model="data.current_password"
                                autocomplete="current-password"
                                required
                            />
                        </x-filament::field>

                        <x-filament::field
                            label="New password"
                            required
                            hint="Minimum 8 characters, with upper/lower case and numbers."
                        >
                            <x-filament::input
                                type="password"
                                wire:model="data.new_password"
                                autocomplete="new-password"
                                required
                            />
                        </x-filament::field>

                        <x-filament::field
                            label="Confirm new password"
                            required
                        >
                            <x-filament::input
                                type="password"
                                wire:model="data.new_password_confirmation"
                                autocomplete="new-password"
                                required
                            />
                        </x-filament::field>

                        <x-filament::button type="submit" color="primary">
                            Change password
                        </x-filament::button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-filament-panels::page>
