<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasRoles;

    protected $fillable = [
        'name', 'email', 'password',
        'hospital_id', 'department_id', 'default_clinic_id',
        'phone', 'avatar_url', 'status',
        'last_login_at', 'last_login_ip',
        'must_change_password', 'default_password', 'active_role',
    ];

    protected $hidden = [
        'password', 'remember_token', 'default_password',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at'     => 'datetime',
            'password'              => 'hashed',
            'last_login_at'         => 'datetime',
            'must_change_password'  => 'boolean',
        ];
    }

    /* ---------------------------------------------------------------------
     *  Auto-generate default password on create
     * ------------------------------------------------------------------- */
    protected static function booted()
    {
        static::creating(function (User $user) {
            // If no password was provided, auto-generate one
            if (empty($user->password)) {
                $plain = static::generateDefaultPassword();
                $user->password = $plain;
                $user->default_password = $plain;
                $user->must_change_password = true;
            } elseif ($user->must_change_password === false) {
                // Password was explicitly set — no force-change needed
                $user->must_change_password = false;
            }
        });
    }

    /**
     * Generate a human-readable default password like "Futh@Xk9Pm".
     */
    public static function generateDefaultPassword(): string
    {
        return 'Futh@' . strtoupper(Str::random(6));
    }

    /* ---------------------------------------------------------------------
     *  Relationships
     * ------------------------------------------------------------------- */
    public function hospital(): BelongsTo { return $this->belongsTo(Hospital::class); }
    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
    public function defaultClinic(): BelongsTo { return $this->belongsTo(Clinic::class, 'default_clinic_id'); }
    public function staff(): HasMany { return $this->hasMany(Staff::class); }

    public function dutyPostings(): HasMany
    {
        return $this->hasMany(DutyPosting::class);
    }

    public function currentDutyPosting()
    {
        $today = now()->toDateString();

        return $this->hasOne(DutyPosting::class)
            ->where('status', 'Active')
            ->where('start_date', '<=', $today)
            ->where('end_date', '>=', $today)
            ->latest('id');
    }

    /* ---------------------------------------------------------------------
     *  Role helpers
     * ------------------------------------------------------------------- */
    public function hasAnyRole(array|string $roles): bool
    {
        foreach ((array) $roles as $role) {
            if ($this->hasRole($role)) return true;
        }
        return false;
    }

    public function isSuperAdmin(): bool { return $this->hasRole('super_admin'); }
    public function isMedicalAdmin(): bool { return $this->hasAnyRole(['super_admin', 'medical_administrator']); }

    /**
     * Get all role names assigned to this user.
     */
    public function getRoleNames(): \Illuminate\Support\Collection
    {
        return $this->roles()->pluck('name');
    }

    /**
     * Does this user have more than one role?
     */
    public function hasMultipleRoles(): bool
    {
        return $this->roles()->count() > 1;
    }

    /**
     * Get the currently active role (the one the user has switched to).
     * Falls back to the first assigned role if no explicit active role is set.
     */
    public function getActiveRole(): ?string
    {
        if ($this->active_role) {
            // Verify the stored active role is still actually assigned
            if ($this->hasRole($this->active_role)) {
                return $this->active_role;
            }
            // Role was removed but active_role wasn't updated — fall through
        }

        $firstRole = $this->roles()->first();
        return $firstRole?->name;
    }

    /**
     * Switch the user's active role. The role must be one the user already has.
     */
    public function switchActiveRole(string $roleName): bool
    {
        if (! $this->hasRole($roleName)) {
            return false;
        }
        $this->update(['active_role' => $roleName]);
        return true;
    }

    /**
     * Clear the active role (revert to "first assigned role" behaviour).
     */
    public function clearActiveRole(): void
    {
        $this->update(['active_role' => null]);
    }

    /* ---------------------------------------------------------------------
     *  Password helpers
     * ------------------------------------------------------------------- */
    public function mustChangePassword(): bool
    {
        return (bool) $this->must_change_password;
    }

    /**
     * Change the user's password and clear the must-change flag.
     */
    public function changePassword(string $newPassword): void
    {
        $this->update([
            'password'              => $newPassword,
            'must_change_password'  => false,
            'default_password'      => null,
        ]);
    }

    /* ---------------------------------------------------------------------
     *  Unit-based access scope helper
     * ------------------------------------------------------------------- */
    public function scopeContext(): ?array
    {
        if ($this->isMedicalAdmin()) return null;

        $posting = $this->currentDutyPosting;

        if ($posting) {
            return [
                'hospital_id'   => $posting->hospital_id,
                'department_id' => $posting->department_id,
                'clinic_id'     => $posting->clinic_id,
            ];
        }

        return [
            'hospital_id'   => $this->hospital_id,
            'department_id' => $this->department_id,
            'clinic_id'     => $this->default_clinic_id,
        ];
    }

    public function updateLastLogin(string $ip = null): void
    {
        $this->update([
            'last_login_at' => now(),
            'last_login_ip' => $ip,
        ]);
    }
}
