@extends('public.layout')

@section('title', 'Online Registration Unavailable')

@section('content')
<section class="futh-section">
    <div class="futh-container futh-container--narrow">
        <div class="futh-auth__card">
            <div class="futh-center">
                <div style="width:64px; height:64px; border-radius:50%; background: #fef3c7; color: #92400e; display:grid; place-items:center; margin: 0 auto 1rem; font-size: 2rem;">&#9888;</div>
                <h1>Online registration not yet available</h1>
                <p class="futh-muted">No hospitals have been configured for online patient registration yet. Please visit any of our hospitals in person, or ask your administrator to enable online registration for a hospital.</p>
            </div>
            <div class="futh-center futh-mt-3">
                <a href="{{ route('public.landing') }}" class="futh-btn futh-btn--primary">Back to home</a>
            </div>
        </div>
    </div>
</section>
@endsection
