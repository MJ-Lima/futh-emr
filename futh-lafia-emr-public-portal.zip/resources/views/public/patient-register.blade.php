@extends('public.layout')

@section('title', 'Register as a Patient')

@section('content')
<section class="futh-auth">
    <div class="futh-container">
        <div class="futh-auth__card futh-auth__card--wide">
            <div class="futh-auth__title"><h1>Register as a New Patient</h1></div>
            <p class="futh-auth__sub">Create your patient record at any of our network hospitals. A hospital number will be generated for you and our front-desk team will verify your details.</p>

            <div class="futh-steps">
                <div class="futh-steps__item done">Choose hospital</div>
                <div class="futh-steps__item active">Personal details</div>
                <div class="futh-steps__item">Next of kin</div>
                <div class="futh-steps__item">Account &amp; finish</div>
            </div>

            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    Please correct the highlighted fields below:
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="post" action="{{ route('public.patient.register.store') }}" class="futh-form">
                @csrf

                <div class="futh-form__section">
                    <h3>1. Choose your hospital</h3>
                    <div class="futh-field">
                        <label for="hospital_id">Hospital <span class="req">*</span></label>
                        <select id="hospital_id" name="hospital_id" required>
                            @foreach ($hospitals as $hospital)
                                <option value="{{ $hospital->id }}" @selected($selected && $selected->id === $hospital->id)>
                                    {{ $hospital->name }} &mdash; {{ $hospital->city ?: $hospital->state }}
                                </option>
                            @endforeach
                        </select>
                        <span class="help">You can register at any hospital in our network.</span>
                    </div>

                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="patient_type">Patient type <span class="req">*</span></label>
                            <select id="patient_type" name="patient_type" required>
                                <option value="private" @selected(old('patient_type','private')==='private')>Private (Self Pay)</option>
                                <option value="nhia" @selected(old('patient_type')==='nhia')>NHIA</option>
                                <option value="nashia" @selected(old('patient_type')==='nashia')>NASHIA</option>
                                <option value="retainership" @selected(old('patient_type')==='retainership')>Retainership</option>
                                <option value="corporate" @selected(old('patient_type')==='corporate')>Corporate</option>
                                <option value="other_insurance" @selected(old('patient_type')==='other_insurance')>Other Insurance</option>
                            </select>
                        </div>
                        <div class="futh-field">
                            <label for="national_id_type">National ID type</label>
                            <select id="national_id_type" name="national_id_type">
                                <option value="">None</option>
                                <option value="NIN" @selected(old('national_id_type')==='NIN')>NIN</option>
                                <option value="Voter Card" @selected(old('national_id_type')==='Voter Card')>Voter Card</option>
                                <option value="Driver License" @selected(old('national_id_type')==='Driver License')>Driver License</option>
                                <option value="International Passport" @selected(old('national_id_type')==='International Passport')>International Passport</option>
                                <option value="Birth Certificate" @selected(old('national_id_type')==='Birth Certificate')>Birth Certificate</option>
                                <option value="Other" @selected(old('national_id_type')==='Other')>Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="national_id">National ID number</label>
                        <input type="text" id="national_id" name="national_id" value="{{ old('national_id') }}" maxlength="50">
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>2. Personal information</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="firstname">First name <span class="req">*</span></label>
                            <input type="text" id="firstname" name="firstname" value="{{ old('firstname') }}" required maxlength="200">
                        </div>
                        <div class="futh-field">
                            <label for="middlename">Middle name</label>
                            <input type="text" id="middlename" name="middlename" value="{{ old('middlename') }}" maxlength="200">
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="lastname">Surname <span class="req">*</span></label>
                            <input type="text" id="lastname" name="lastname" value="{{ old('lastname') }}" required maxlength="200">
                        </div>
                        <div class="futh-field">
                            <label for="dob">Date of birth <span class="req">*</span></label>
                            <input type="date" id="dob" name="dob" value="{{ old('dob') }}" required>
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="gender">Gender <span class="req">*</span></label>
                            <select id="gender" name="gender" required>
                                <option value="">Select</option>
                                <option value="Male" @selected(old('gender')==='Male')>Male</option>
                                <option value="Female" @selected(old('gender')==='Female')>Female</option>
                                <option value="Other" @selected(old('gender')==='Other')>Other</option>
                            </select>
                        </div>
                        <div class="futh-field">
                            <label for="marital">Marital status</label>
                            <select id="marital" name="marital">
                                <option value="">Select</option>
                                <option value="Single" @selected(old('marital')==='Single')>Single</option>
                                <option value="Married" @selected(old('marital')==='Married')>Married</option>
                                <option value="Divorced" @selected(old('marital')==='Divorced')>Divorced</option>
                                <option value="Widowed" @selected(old('marital')==='Widowed')>Widowed</option>
                            </select>
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="religion">Religion</label>
                            <input type="text" id="religion" name="religion" value="{{ old('religion') }}" maxlength="200">
                        </div>
                        <div class="futh-field">
                            <label for="occupation">Occupation</label>
                            <input type="text" id="occupation" name="occupation" value="{{ old('occupation') }}" maxlength="255">
                        </div>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>3. Contact information</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="phonemain">Main phone <span class="req">*</span></label>
                            <input type="tel" id="phonemain" name="phonemain" value="{{ old('phonemain') }}" required maxlength="13" placeholder="08030000001">
                        </div>
                        <div class="futh-field">
                            <label for="phonealt">Alternative phone</label>
                            <input type="tel" id="phonealt" name="phonealt" value="{{ old('phonealt') }}" maxlength="13">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="email">Email address <span class="req">*</span></label>
                        <input type="email" id="email" name="email" value="{{ old('email') }}" required maxlength="250">
                        <span class="help">This will be your patient portal login.</span>
                    </div>
                    <div class="futh-field">
                        <label for="address">Residential address <span class="req">*</span></label>
                        <textarea id="address" name="address" rows="2" required maxlength="500">{{ old('address') }}</textarea>
                    </div>
                    <div class="futh-grid-3">
                        <div class="futh-field">
                            <label for="city">City <span class="req">*</span></label>
                            <input type="text" id="city" name="city" value="{{ old('city') }}" required maxlength="250">
                        </div>
                        <div class="futh-field">
                            <label for="state">State <span class="req">*</span></label>
                            <input type="text" id="state" name="state" value="{{ old('state', 'Nasarawa') }}" required maxlength="250">
                        </div>
                        <div class="futh-field">
                            <label for="country">Country</label>
                            <input type="text" id="country" name="country" value="{{ old('country', 'Nigeria') }}" maxlength="250">
                        </div>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>4. Next of kin</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="nokname">Next of kin full name <span class="req">*</span></label>
                            <input type="text" id="nokname" name="nokname" value="{{ old('nokname') }}" required maxlength="250">
                        </div>
                        <div class="futh-field">
                            <label for="relationship">Relationship <span class="req">*</span></label>
                            <input type="text" id="relationship" name="relationship" value="{{ old('relationship') }}" required maxlength="250" placeholder="e.g. Father, Spouse">
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="nokphone">Next of kin phone <span class="req">*</span></label>
                            <input type="tel" id="nokphone" name="nokphone" value="{{ old('nokphone') }}" required maxlength="250">
                        </div>
                        <div class="futh-field">
                            <label for="nok_firstname">Next of kin first name</label>
                            <input type="text" id="nok_firstname" name="nok_firstname" value="{{ old('nok_firstname') }}" maxlength="250">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="nokaddress">Next of kin address <span class="req">*</span></label>
                        <textarea id="nokaddress" name="nokaddress" rows="2" required maxlength="500">{{ old('nokaddress') }}</textarea>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>5. Patient portal account</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="password">Create password <span class="req">*</span></label>
                            <input type="password" id="password" name="password" required minlength="8">
                            <span class="help">Minimum 8 characters.</span>
                        </div>
                        <div class="futh-field">
                            <label for="password_confirmation">Confirm password <span class="req">*</span></label>
                            <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="hereabout">How did you hear about us?</label>
                        <select id="hereabout" name="hereabout">
                            <option value="Online Portal" @selected(old('hereabout')==='Online Portal')>Online Portal</option>
                            <option value="Friend/Family" @selected(old('hereabout')==='Friend/Family')>Friend/Family</option>
                            <option value="Hospital Signage" @selected(old('hereabout')==='Hospital Signage')>Hospital Signage</option>
                            <option value="Radio/TV" @selected(old('hereabout')==='Radio/TV')>Radio/TV</option>
                            <option value="Social Media" @selected(old('hereabout')==='Social Media')>Social Media</option>
                            <option value="Doctor Referral" @selected(old('hereabout')==='Doctor Referral')>Doctor Referral</option>
                        </select>
                    </div>
                </div>

                <div style="display:flex; gap:0.75rem; justify-content:flex-end;">
                    <a href="{{ route('public.landing') }}" class="futh-btn futh-btn--ghost">Cancel</a>
                    <button type="submit" class="futh-btn futh-btn--primary futh-btn--lg">Submit registration</button>
                </div>
            </form>
        </div>
    </div>
</section>
@endsection
