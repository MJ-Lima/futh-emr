<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Console\Scheduling\Schedule;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Guard-aware guest redirect: patient-portal routes go to the patient
        // portal login, everything else goes to the staff (Filament) admin login.
        $middleware->redirectGuestsTo(function (Request $request) {
            if ($request->is('portal*') || $request->is('portal/*')) {
                return route('portal.login');
            }
            return '/admin/login';
        });
    })
    ->withSchedule(function (Schedule $schedule) {
        $schedule->command('cashier:auto-logout')->everyMinute();
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();