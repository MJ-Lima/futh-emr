@extends('portal.layout')

@section('title', 'My Prescriptions')

@section('content')
<div class="futh-panel">
    <div class="futh-panel__head"><h3>Prescriptions</h3></div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($prescriptions) > 0)
        @foreach ($prescriptions as $rx)
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--futh-border);">
            <div class="futh-flex futh-flex--between futh-flex--center futh-mb-1">
                <div>
                    <strong>{{ $rx->prescription_number }}</strong>
                    <span class="futh-muted" style="font-size:0.85rem;">&middot; {{ \Carbon\Carbon::parse($rx->prescribed_at)->format('d M Y') }}</span>
                    <span class="futh-muted" style="font-size:0.85rem;">&middot; by {{ $rx->prescriber?->name }}</span>
                </div>
                <span class="futh-badge futh-badge--{{ $rx->status === 'Dispensed' ? 'green' : ($rx->status === 'Cancelled' || $rx->status === 'Rejected' ? 'red' : 'amber') }}">{{ $rx->status }}</span>
            </div>
            @if ($rx->items->count())
            <table class="futh-table" style="font-size:0.85rem;">
                <thead><tr><th>Drug</th><th>Dose</th><th>Frequency</th><th>Duration</th><th>Qty</th><th>Dispensed</th></tr></thead>
                <tbody>
                    @foreach ($rx->items as $item)
                    <tr>
                        <td><strong>{{ $item->drug_name }}</strong></td>
                        <td>{{ $item->dose }}</td>
                        <td>{{ $item->frequency }}</td>
                        <td>{{ $item->duration }}</td>
                        <td>{{ $item->quantity }}</td>
                        <td>{{ $item->quantity_dispensed }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            @else
            <p class="futh-muted" style="font-size:0.85rem;">No items.</p>
            @endif
            @if ($rx->notes)
            <p class="futh-muted futh-mt-1" style="font-size:0.85rem;"><strong>Notes:</strong> {{ $rx->notes }}</p>
            @endif
        </div>
        @endforeach
        @else
        <div class="futh-table__empty">No prescriptions yet. They will appear here once prescribed by your doctor.</div>
        @endif
    </div>
</div>
<div class="futh-center">{{ $prescriptions->links() ?? '' }}</div>
@endsection
