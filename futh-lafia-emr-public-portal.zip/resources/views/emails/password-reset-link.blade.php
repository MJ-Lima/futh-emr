<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>FUTH Lafia — Password Reset</title>
</head>
<body style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #1f2937;">
    <div style="background: #0f5132; padding: 20px; border-radius: 8px 8px 0 0; color: #fff;">
        <h1 style="margin: 0; font-family: Georgia, serif; font-size: 22px;">FUTH Lafia EMR</h1>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.85;">{{ $userType === 'patient' ? 'Patient Portal' : 'Staff Portal' }}</p>
    </div>

    <div style="background: #fff; padding: 24px; border: 1px solid #e5e7eb; border-top: 0; border-radius: 0 0 8px 8px;">
        <h2 style="margin-top: 0;">Reset your password</h2>
        <p>You requested a password reset for your FUTH Lafia {{ $userType === 'patient' ? 'patient portal' : 'staff' }} account.</p>

        <p style="text-align: center; margin: 24px 0;">
            <a href="{{ $resetUrl }}" style="background: #0f5132; color: #fff; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: 600; display: inline-block;">Reset password</a>
        </p>

        <p style="font-size: 13px; color: #6b7280;">Or copy and paste this link into your browser:</p>
        <p style="font-family: monospace; font-size: 12px; background: #f8fafb; padding: 10px; border-radius: 4px; word-break: break-all;">{{ $resetUrl }}</p>

        <p style="font-size: 13px; color: #6b7280;">This reset link will expire in {{ $expiresMinutes }} minutes.</p>
        <p style="font-size: 13px; color: #6b7280;">If you did not request this password reset, you can safely ignore this email — your password remains unchanged.</p>

        <p style="margin-top: 28px; font-size: 12px; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 12px;">
            Federal University Teaching Hospital, Lafia &middot; Nasarawa State, Nigeria
        </p>
    </div>
</body>
</html>
