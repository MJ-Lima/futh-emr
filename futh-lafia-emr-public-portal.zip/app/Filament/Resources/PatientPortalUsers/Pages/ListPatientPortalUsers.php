<?php

namespace App\Filament\Resources\PatientPortalUsers\Pages;

use App\Filament\Resources\PatientPortalUsers\PatientPortalUserResource;
use Filament\Resources\Pages\ListRecords;

class ListPatientPortalUsers extends ListRecords
{
    protected static string $resource = PatientPortalUserResource::class;
}
