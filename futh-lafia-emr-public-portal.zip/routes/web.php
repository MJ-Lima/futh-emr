<?php

use App\Http\Controllers\Auth\PasswordResetController;
use App\Http\Controllers\ConsultationNotePrintController;
use App\Http\Controllers\DischargeSummaryPrintController;
use App\Http\Controllers\DispensingLogExportController;
use App\Http\Controllers\DutyRosterExportController;
use App\Http\Controllers\InsuranceClaimPrintController;
use App\Http\Controllers\InventoryValuationExportController;
use App\Http\Controllers\LabOrderPrintController;
use App\Http\Controllers\MedicalCertificatePrintController;
use App\Http\Controllers\MortalityReviewExportController;
use App\Http\Controllers\PatientPortal\AppointmentController;
use App\Http\Controllers\PatientPortal\AuthController;
use App\Http\Controllers\PatientPortal\DashboardController;
use App\Http\Controllers\PatientPortal\MessageController;
use App\Http\Controllers\Provider\RegistrationController as ProviderRegistrationController;
use App\Http\Controllers\PublicPortal\FeedbackController;
use App\Http\Controllers\PublicPortal\LandingController;
use App\Http\Controllers\PublicPortal\PatientRegistrationController;
use App\Http\Controllers\ReferralPrintController;
use App\Http\Controllers\ReportingTableExportController;
use App\Http\Controllers\StockReorderExportController;
use App\Http\Controllers\WardRoundNotePrintController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public-facing routes (FUTH Lafia public portal)
|--------------------------------------------------------------------------
*/
Route::name('public.')->group(function () {
    Route::get('/', [LandingController::class, 'index'])->name('landing');
    Route::get('/hospitals', [LandingController::class, 'directory'])->name('directory');
    Route::get('/hospitals/{hospital}', [LandingController::class, 'showHospital'])->name('hospital');
    Route::get('/about', [LandingController::class, 'about'])->name('about');
    Route::get('/ajax/clinics', [LandingController::class, 'clinics'])->name('ajax.clinics');

    // New patient self-registration at any network hospital.
    // NOTE: literal routes (/register and /register/success) must be declared
    // BEFORE the parameterised /register/{hospital} route so they win.
    Route::get('/register', [PatientRegistrationController::class, 'create'])->name('patient.register');
    Route::get('/register/success', [PatientRegistrationController::class, 'success'])->name('patient.register.success');
    Route::post('/register', [PatientRegistrationController::class, 'store'])->name('patient.register.store');
    Route::get('/register/{hospital}', [PatientRegistrationController::class, 'create'])->name('patient.register.hospital');

    // Public patient feedback form (no login required)
    Route::get('/feedback', [FeedbackController::class, 'create'])->name('feedback.create');
    Route::post('/feedback', [FeedbackController::class, 'store'])->name('feedback.store');
    Route::get('/feedback/success/{survey}', [FeedbackController::class, 'success'])->name('feedback.success');
});

/*
|--------------------------------------------------------------------------
| Staff password reset (web guard — Filament admin users)
|--------------------------------------------------------------------------
*/
Route::name('password.')->middleware('web')->group(function () {
    Route::get('/password/forgot', [PasswordResetController::class, 'showRequestForm'])->name('request');
    Route::post('/password/forgot', [PasswordResetController::class, 'sendResetLink'])->name('email');
    Route::get('/password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('reset');
    Route::post('/password/reset', [PasswordResetController::class, 'update'])->name('update');
});

/*
|--------------------------------------------------------------------------
| Provider (private doctor / hospital) registration
|--------------------------------------------------------------------------
*/
Route::name('provider.')->prefix('providers')->group(function () {
    Route::get('/', [ProviderRegistrationController::class, 'index'])->name('index');
    Route::get('/doctors/register', [ProviderRegistrationController::class, 'createDoctor'])->name('doctor.register');
    Route::post('/doctors/register', [ProviderRegistrationController::class, 'storeDoctor'])->name('doctor.register.store');
    Route::get('/hospitals/register', [ProviderRegistrationController::class, 'createHospital'])->name('hospital.register');
    Route::post('/hospitals/register', [ProviderRegistrationController::class, 'storeHospital'])->name('hospital.register.store');
    Route::get('/success/{application}', [ProviderRegistrationController::class, 'success'])->name('success');
});

/*
|--------------------------------------------------------------------------
| Patient portal (authenticated)
|--------------------------------------------------------------------------
*/
Route::name('portal.')->prefix('portal')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Patient portal password reset (patient_portal guard)
    Route::get('/password/forgot', [PasswordResetController::class, 'showRequestForm'])->name('password.request');
    Route::post('/password/forgot', [PasswordResetController::class, 'sendResetLink'])->name('password.email');
    Route::get('/password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
    Route::post('/password/reset', [PasswordResetController::class, 'update'])->name('password.update');

    Route::get('/appointments/slots', [AppointmentController::class, 'slots'])->name('appointments.slots');

    Route::middleware(['auth:patient_portal'])->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('/encounters', [DashboardController::class, 'encounters'])->name('encounters');
        Route::get('/lab-results', [DashboardController::class, 'labResults'])->name('lab-results');
        Route::get('/prescriptions', [DashboardController::class, 'prescriptions'])->name('prescriptions');
        Route::get('/invoices', [DashboardController::class, 'invoices'])->name('invoices');
        Route::get('/receipts', [DashboardController::class, 'receipts'])->name('receipts');

        Route::get('/appointments', [AppointmentController::class, 'index'])->name('appointments');
        Route::get('/appointments/create', [AppointmentController::class, 'create'])->name('appointments.create');
        Route::post('/appointments', [AppointmentController::class, 'store'])->name('appointments.store');
        Route::delete('/appointments/{appointment}', [AppointmentController::class, 'cancel'])->name('appointments.cancel');

        Route::get('/messages', [MessageController::class, 'index'])->name('messages');
        Route::get('/messages/create', [MessageController::class, 'create'])->name('messages.create');
        Route::post('/messages', [MessageController::class, 'store'])->name('messages.store');
        Route::get('/messages/{message}', [MessageController::class, 'show'])->name('messages.show');
    });
});


// Print / PDF / Export routes (must be authenticated)
Route::middleware(['web', 'auth'])->prefix('admin')->group(function () {
    // Lab orders
    Route::get('/lab-orders/{labOrder}/print', [LabOrderPrintController::class, 'print'])->name('lab-orders.print');
    Route::get('/lab-orders/{labOrder}/pdf', [LabOrderPrintController::class, 'pdf'])->name('lab-orders.pdf');

    // Medical certificates
    Route::get('/medical-certificates/{medicalCertificate}/print', [MedicalCertificatePrintController::class, 'print'])->name('medical-certificates.print');
    Route::get('/medical-certificates/{medicalCertificate}/pdf', [MedicalCertificatePrintController::class, 'pdf'])->name('medical-certificates.pdf');

    // Referrals
    Route::get('/referrals/{referral}/print', [ReferralPrintController::class, 'print'])->name('referrals.print');
    Route::get('/referrals/{referral}/pdf', [ReferralPrintController::class, 'pdf'])->name('referrals.pdf');

    // Consultation notes
    Route::get('/consultation-notes/{consultationNote}/print', [ConsultationNotePrintController::class, 'print'])->name('consultation-notes.print');
    Route::get('/consultation-notes/{consultationNote}/pdf', [ConsultationNotePrintController::class, 'pdf'])->name('consultation-notes.pdf');

    // Ward round notes
    Route::get('/ward-round-notes/{wardRoundNote}/print', [WardRoundNotePrintController::class, 'print'])->name('ward-round-notes.print');
    Route::get('/ward-round-notes/{wardRoundNote}/pdf', [WardRoundNotePrintController::class, 'pdf'])->name('ward-round-notes.pdf');
    Route::get('/ward-round-notes/admission/{admissionId}/bundle', [WardRoundNotePrintController::class, 'admissionBundle'])->name('ward-round-notes.bundle');

    // Discharge summary
    Route::get('/admissions/{admission}/discharge-summary/print', [DischargeSummaryPrintController::class, 'print'])->name('discharge-summaries.print');
    Route::get('/admissions/{admission}/discharge-summary/pdf', [DischargeSummaryPrintController::class, 'pdf'])->name('discharge-summaries.pdf');

    // Reporting Table export (Excel/CSV)
    Route::get('/reporting-table/export', [ReportingTableExportController::class, 'export'])->name('reporting-table.export');
    Route::get('/reporting-table/export-csv', [ReportingTableExportController::class, 'exportCsv'])->name('reporting-table.export-csv');

    // Stock reorder report export (Excel/CSV)
    Route::get('/stock-reorder/export', [StockReorderExportController::class, 'export'])->name('stock-reorder.export');
    Route::get('/stock-reorder/export-csv', [StockReorderExportController::class, 'exportCsv'])->name('stock-reorder.export-csv');

    // Dispensing log export (Excel/CSV)
    Route::get('/dispensing-log/export', [DispensingLogExportController::class, 'export'])->name('dispensing-log.export');
    Route::get('/dispensing-log/export-csv', [DispensingLogExportController::class, 'exportCsv'])->name('dispensing-log.export-csv');

    // Insurance / NHIA claims
    Route::get('/insurance-claims/{insuranceClaim}/print', [InsuranceClaimPrintController::class, 'print'])->name('insurance-claims.print');
    Route::get('/insurance-claims/{insuranceClaim}/pdf', [InsuranceClaimPrintController::class, 'pdf'])->name('insurance-claims.pdf');

    // Mortality review export
    Route::get('/mortality-review/export', [MortalityReviewExportController::class, 'export'])->name('mortality-review.export');
    Route::get('/mortality-review/export-csv', [MortalityReviewExportController::class, 'exportCsv'])->name('mortality-review.export-csv');

    // Duty roster export
    Route::get('/duty-roster/export', [DutyRosterExportController::class, 'export'])->name('duty-roster.export');

    // Inventory valuation export
    Route::get('/inventory-valuation/export', [InventoryValuationExportController::class, 'export'])->name('inventory-valuation.export');
    Route::get('/inventory-valuation/export-csv', [InventoryValuationExportController::class, 'exportCsv'])->name('inventory-valuation.export-csv');
});
