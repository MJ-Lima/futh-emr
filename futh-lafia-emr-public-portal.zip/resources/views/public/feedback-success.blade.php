@extends('public.layout')

@section('title', 'Feedback Submitted')

@section('content')
<section class="futh-section">
    <div class="futh-container futh-container--narrow">
        <div class="futh-auth__card">
            <div class="futh-center">
                <div style="width:64px; height:64px; border-radius:50%; background: var(--futh-green-50); color: var(--futh-green); display:grid; place-items:center; margin: 0 auto 1rem; font-size: 2rem;">&#10003;</div>
                <h1>Thank you for your feedback</h1>
                <p class="futh-muted">Your feedback has been received and will be reviewed by our administration team. We appreciate you taking the time to help us improve.</p>
            </div>

            <div class="futh-panel futh-mt-3">
                <div class="futh-panel__body">
                    <dl class="futh-detail">
                        <dt>Reference number</dt><dd><strong>{{ $surveyNumber }}</strong></dd>
                    </dl>
                    <p class="futh-muted" style="font-size:0.85rem; margin-top:0.5rem;">Please keep this reference number in case you wish to follow up on your feedback.</p>
                </div>
            </div>

            <div class="futh-center futh-mt-3" style="display:flex; gap:0.75rem; justify-content:center;">
                <a href="{{ route('public.feedback.create') }}" class="futh-btn futh-btn--ghost">Submit another</a>
                <a href="{{ route('public.landing') }}" class="futh-btn futh-btn--primary">Back to home</a>
            </div>
        </div>
    </div>
</section>
@endsection
