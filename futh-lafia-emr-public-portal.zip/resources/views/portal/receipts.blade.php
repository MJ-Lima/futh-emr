@extends('portal.layout')

@section('title', 'My Receipts')

@section('content')
<div class="futh-panel">
    <div class="futh-panel__head"><h3>Payment Receipts</h3></div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($receipts) > 0)
        <table class="futh-table">
            <thead><tr><th>Receipt #</th><th>Date</th><th>Description</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
            <tbody>
                @foreach ($receipts as $r)
                <tr>
                    <td><strong>{{ $r->receipt_number }}</strong></td>
                    <td>{{ \Carbon\Carbon::parse($r->receipt_date)->format('d M Y, H:i') }}</td>
                    <td>{{ $r->service_description ?: '&mdash;' }}</td>
                    <td>&#8358;{{ number_format($r->amount, 2) }}</td>
                    <td>{{ $r->payment_method }}</td>
                    <td><span class="futh-badge futh-badge--green">{{ $r->payment_status }}</span></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="futh-table__empty">No receipts yet. Your payment receipts will appear here after each payment.</div>
        @endif
    </div>
</div>
<div class="futh-center">{{ $receipts->links() ?? '' }}</div>
@endsection
