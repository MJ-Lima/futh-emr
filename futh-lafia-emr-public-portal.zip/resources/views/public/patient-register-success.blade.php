@extends('public.layout')

@section('title', 'Registration Received')

@section('content')
<section class="futh-section">
    <div class="futh-container futh-container--narrow">
        <div class="futh-auth__card">
            <div class="futh-center">
                <div style="width:64px; height:64px; border-radius:50%; background: var(--futh-green-50); color: var(--futh-green); display:grid; place-items:center; margin: 0 auto 1rem; font-size: 2rem;">&#10003;</div>
                <h1>Registration received</h1>
                <p class="futh-muted">Thank you, {{ $patient?->full_name }}. Your registration has been submitted to <strong>{{ $hospital?->name }}</strong> and is now pending verification.</p>
            </div>

            <div class="futh-panel futh-mt-3">
                <div class="futh-panel__body">
                    <dl class="futh-detail">
                        <dt>Hospital</dt><dd>{{ $hospital?->name }}</dd>
                        <dt>Patient name</dt><dd>{{ $patient?->full_name }}</dd>
                        <dt>Hospital number</dt><dd><strong>{{ $patient?->hospital_no }}</strong></dd>
                        <dt>Portal username</dt><dd><strong>{{ $portalUser->username }}</strong></dd>
                        <dt>Portal email</dt><dd>{{ $portalUser->email }}</dd>
                        <dt>Status</dt><dd><span class="futh-badge futh-badge--amber">Pending verification</span></dd>
                    </dl>
                </div>
            </div>

            <div class="futh-alert futh-alert--info futh-mt-2">
                Our front-desk team will verify your record shortly. Once verified, you can sign in to the patient portal to book appointments, view lab results, and message your hospital.
            </div>

            <div class="futh-center futh-mt-3" style="display:flex; gap:0.75rem; justify-content:center;">
                <a href="{{ route('portal.login') }}" class="futh-btn futh-btn--primary">Go to Patient Sign In</a>
                <a href="{{ route('public.landing') }}" class="futh-btn futh-btn--ghost">Back to home</a>
            </div>
        </div>
    </div>
</section>
@endsection
