<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'My Portal') &middot; FUTH Lafia</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/futh-public-portal.css') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @stack('head')
</head>
<body class="futh-public">
<div class="futh-portal">
    <aside class="futh-portal__sidebar" id="portal-sidebar">
        <div class="futh-portal__brand">
            <span class="logo">FL</span>
            <div>
                <div class="name">FUTH Lafia</div>
                <div class="sub">Patient Portal</div>
            </div>
        </div>

        @php
            $navItems = [
                ['route' => 'portal.dashboard', 'icon' => '&#127968;', 'label' => 'Dashboard'],
                ['route' => 'portal.appointments', 'icon' => '&#128197;', 'label' => 'Appointments'],
                ['route' => 'portal.encounters', 'icon' => '&#128221;', 'label' => 'Encounters'],
                ['route' => 'portal.lab-results', 'icon' => '&#128202;', 'label' => 'Lab Results'],
                ['route' => 'portal.prescriptions', 'icon' => '&#128138;', 'label' => 'Prescriptions'],
                ['route' => 'portal.invoices', 'icon' => '&#128176;', 'label' => 'Invoices'],
                ['route' => 'portal.receipts', 'icon' => '&#129534;', 'label' => 'Receipts'],
                ['route' => 'portal.messages', 'icon' => '&#128172;', 'label' => 'Messages'],
            ];
        @endphp

        <div class="futh-portal__nav">
            @foreach ($navItems as $item)
                <a href="{{ route($item['route']) }}" class="@if (request()->routeIs($item['route']) || request()->routeIs(str_replace('portal.', 'portal.', $item['route']).'.*')) active @endif">
                    <span>{!! $item['icon'] !!}</span> {{ $item['label'] }}
                </a>
            @endforeach

            <div class="section">Account</div>
            <a href="{{ route('public.landing') }}"><span>&#8599;</span> Public site</a>
            <a href="{{ route('portal.logout') }}"><span>&#8635;</span> Sign out</a>
        </div>
    </aside>

    <div class="futh-portal__main">
        <div class="futh-portal__topbar">
            <button class="futh-portal__menu-toggle futh-btn futh-btn--ghost futh-btn--sm" onclick="document.getElementById('portal-sidebar').classList.toggle('open')">&#9776; Menu</button>
            <h1>@yield('title', 'Dashboard')</h1>
            <div class="futh-portal__user">
                @php $u = Auth::guard('patient_portal')->user(); @endphp
                <div>
                    <div style="font-weight:600;">{{ $u?->patient?->full_name ?: $u?->username }}</div>
                    <div style="font-size:0.78rem; color: var(--futh-muted);">{{ $u?->email }}</div>
                </div>
                <span class="futh-portal__avatar">{{ strtoupper(Str::substr($u?->patient?->firstname ?: $u?->username, 0, 1)) }}</span>
            </div>
        </div>

        @if (session('success')) <div class="futh-alert futh-alert--success">{{ session('success') }}</div> @endif
        @if (session('danger') || session('error')) <div class="futh-alert futh-alert--danger">{{ session('danger') ?? session('error') }}</div> @endif
        @if (session('warning')) <div class="futh-alert futh-alert--warning">{{ session('warning') }}</div> @endif
        @if (session('info')) <div class="futh-alert futh-alert--info">{{ session('info') }}</div> @endif

        @yield('content')
    </div>
</div>

@stack('scripts')
</body>
</html>
