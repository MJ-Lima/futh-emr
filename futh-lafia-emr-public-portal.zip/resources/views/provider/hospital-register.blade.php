@extends('public.layout')

@section('title', 'Hospital / Clinic Registration')

@section('content')
<section class="futh-auth">
    <div class="futh-container">
        <div class="futh-auth__card futh-auth__card--wide">
            <div class="futh-auth__title"><h1>Hospital / Clinic Registration</h1></div>
            <p class="futh-auth__sub">Onboard your hospital or clinic to the FUTH Lafia network. Our administration will verify your facility license before activation.</p>

            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    Please correct the highlighted fields:
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="post" action="{{ route('provider.hospital.register.store') }}" class="futh-form">
                @csrf

                <div class="futh-form__section">
                    <h3>Account type</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="account_type">Facility type <span class="req">*</span></label>
                            <select id="account_type" name="account_type" required>
                                <option value="hospital" @selected(old('account_type','hospital')==='hospital')>Hospital</option>
                                <option value="clinic" @selected(old('account_type')==='clinic')>Clinic</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Facility details</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="facility_name">Facility name <span class="req">*</span></label>
                            <input type="text" id="facility_name" name="facility_name" value="{{ old('facility_name') }}" required maxlength="255">
                        </div>
                        <div class="futh-field">
                            <label for="facility_type">Facility category <span class="req">*</span></label>
                            <select id="facility_type" name="facility_type" required>
                                <option value="">Select</option>
                                @foreach (['Teaching', 'General', 'Specialist', 'Clinic', 'Maternity', 'Primary'] as $t)
                                    <option value="{{ $t }}" @selected(old('facility_type')===$t)>{{ $t }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="facility_license_number">Facility license number <span class="req">*</span></label>
                            <input type="text" id="facility_license_number" name="facility_license_number" value="{{ old('facility_license_number') }}" required maxlength="100">
                        </div>
                        <div class="futh-field">
                            <label for="website">Website</label>
                            <input type="url" id="website" name="website" value="{{ old('website') }}" maxlength="255" placeholder="https://">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="facility_address">Facility address <span class="req">*</span></label>
                        <textarea id="facility_address" name="facility_address" rows="2" required maxlength="500">{{ old('facility_address') }}</textarea>
                    </div>
                    <div class="futh-grid-3">
                        <div class="futh-field">
                            <label for="facility_city">City <span class="req">*</span></label>
                            <input type="text" id="facility_city" name="facility_city" value="{{ old('facility_city') }}" required maxlength="150">
                        </div>
                        <div class="futh-field">
                            <label for="facility_state">State <span class="req">*</span></label>
                            <input type="text" id="facility_state" name="facility_state" value="{{ old('facility_state') }}" required maxlength="150">
                        </div>
                        <div class="futh-field">
                            <label for="facility_country">Country</label>
                            <input type="text" id="facility_country" name="facility_country" value="{{ old('facility_country', 'Nigeria') }}" maxlength="150">
                        </div>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Administrator / owner</h3>
                    <p class="help" style="margin-bottom: 0.75rem;">This person will be the primary contact for the facility account.</p>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="applicant_name">Administrator full name <span class="req">*</span></label>
                            <input type="text" id="applicant_name" name="applicant_name" value="{{ old('applicant_name') }}" required maxlength="255">
                        </div>
                        <div class="futh-field">
                            <label for="phone">Phone <span class="req">*</span></label>
                            <input type="tel" id="phone" name="phone" value="{{ old('phone') }}" required maxlength="30">
                        </div>
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Services offered</h3>
                    <p class="help" style="margin-bottom: 0.5rem;">Select all services your facility provides.</p>
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.5rem;">
                        @foreach (['Outpatient', 'Inpatient', 'Emergency', 'Maternity', 'Surgery', 'Pharmacy', 'Laboratory', 'Radiology', 'Ultrasound', 'Physiotherapy', 'Dental', 'Eye Clinic', 'Mental Health', 'Vaccination', 'Antenatal', 'HIV Care', 'Telemedicine'] as $service)
                        <label style="display:flex; align-items:center; gap:0.5rem; font-size:0.9rem; padding: 0.4rem 0.65rem; border: 1px solid var(--futh-border); border-radius: 8px;">
                            <input type="checkbox" name="services_offered[]" value="{{ $service }}" @checked(in_array($service, old('services_offered', [])))>
                            {{ $service }}
                        </label>
                        @endforeach
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Account security</h3>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="email">Login email <span class="req">*</span></label>
                            <input type="email" id="email" name="email" value="{{ old('email') }}" required maxlength="255">
                            <span class="help">This will be the facility&rsquo;s login.</span>
                        </div>
                        <div class="futh-field">
                            <label for="password">Create password <span class="req">*</span></label>
                            <input type="password" id="password" name="password" required minlength="8">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="password_confirmation">Confirm password <span class="req">*</span></label>
                        <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">
                    </div>
                </div>

                <div style="display:flex; gap:0.75rem; justify-content:flex-end;">
                    <a href="{{ route('provider.index') }}" class="futh-btn futh-btn--ghost">Back</a>
                    <button type="submit" class="futh-btn futh-btn--primary futh-btn--lg">Submit application</button>
                </div>
            </form>
        </div>
    </div>
</section>
@endsection
