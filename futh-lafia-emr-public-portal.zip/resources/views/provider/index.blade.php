@extends('public.layout')

@section('title', 'For Providers')

@section('content')
<section class="futh-hero">
    <div class="futh-container futh-hero__inner">
        <span class="futh-eyebrow" style="background: rgba(255,255,255,0.14); color: var(--futh-gold-light);">For Providers</span>
        <h1>Join the <span class="gold">FUTH Lafia</span> network</h1>
        <p class="futh-hero__lead">Private doctors and external hospitals are welcome to register for a verified provider account. Refer patients, share records, and collaborate with our clinical teams.</p>
    </div>
</section>

<section class="futh-section">
    <div class="futh-container">
        <div class="futh-hospital-grid">
            <div class="futh-card">
                <div class="futh-card__cover" style="height: 160px;">
                    <span style="font-family: var(--futh-font-serif); font-size: 3rem;">&#129518;</span>
                </div>
                <div class="futh-card__body">
                    <h3 class="futh-card__title">Private Doctor</h3>
                    <p class="futh-card__sub">Individual medical practitioner</p>
                    <div class="futh-card__meta">
                        <span><i>&#10003;</i> Personal provider account</span>
                        <span><i>&#10003;</i> Refer patients to our network</span>
                        <span><i>&#10003;</i> MDCN / professional registration required</span>
                        <span><i>&#10003;</i> Admin approval required</span>
                    </div>
                </div>
                <div class="futh-card__footer">
                    <a href="{{ route('provider.doctor.register') }}" class="futh-btn futh-btn--primary futh-btn--block">Register as Doctor</a>
                </div>
            </div>

            <div class="futh-card">
                <div class="futh-card__cover" style="height: 160px;">
                    <span style="font-family: var(--futh-font-serif); font-size: 3rem;">&#127973;</span>
                </div>
                <div class="futh-card__body">
                    <h3 class="futh-card__title">Hospital / Clinic</h3>
                    <p class="futh-card__sub">Institutional account</p>
                    <div class="futh-card__meta">
                        <span><i>&#10003;</i> Onboard your facility</span>
                        <span><i>&#10003;</i> Add departments &amp; clinics</span>
                        <span><i>&#10003;</i> Facility license required</span>
                        <span><i>&#10003;</i> Admin approval required</span>
                    </div>
                </div>
                <div class="futh-card__footer">
                    <a href="{{ route('provider.hospital.register') }}" class="futh-btn futh-btn--gold futh-btn--block">Register Hospital / Clinic</a>
                </div>
            </div>

            <div class="futh-card">
                <div class="futh-card__cover" style="height: 160px;">
                    <span style="font-family: var(--futh-font-serif); font-size: 3rem;">&#128737;</span>
                </div>
                <div class="futh-card__body">
                    <h3 class="futh-card__title">Already registered?</h3>
                    <p class="futh-card__sub">Sign in to continue</p>
                    <div class="futh-card__meta">
                        <span>If your application has already been approved, sign in to the staff portal to continue.</span>
                    </div>
                </div>
                <div class="futh-card__footer">
                    <a href="{{ route('filament.admin.auth.login') }}" class="futh-btn futh-btn--ghost futh-btn--block">Staff Login</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="futh-section futh-section--soft">
    <div class="futh-container futh-container--narrow">
        <div class="futh-section__head">
            <span class="futh-eyebrow">How it works</span>
            <h2>The registration process</h2>
        </div>
        <div class="futh-services-grid">
            <div class="futh-service">
                <div class="futh-service__icon">1</div>
                <h3>Submit application</h3>
                <p>Complete the doctor or hospital registration form with your professional details.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">2</div>
                <h3>Admin review</h3>
                <p>Our administration verifies your professional registration and facility license.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">3</div>
                <h3>Account activation</h3>
                <p>Once approved, your provider account is activated and you can sign in.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">4</div>
                <h3>Start collaborating</h3>
                <p>Refer patients, share records, and access the network&rsquo;s clinical resources.</p>
            </div>
        </div>
    </div>
</section>
@endsection
