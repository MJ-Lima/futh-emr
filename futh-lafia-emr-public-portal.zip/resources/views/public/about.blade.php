@extends('public.layout')

@section('title', 'About Us')

@section('content')
<section class="futh-section">
    <div class="futh-container futh-container--narrow">
        <div class="futh-section__head">
            <span class="futh-eyebrow">About Us</span>
            <h2>Our mission, our network</h2>
        </div>
        <p>The <strong>Federal University Teaching Hospital, Lafia</strong> is a leading tertiary healthcare institution serving Nasarawa State and surrounding communities. Through this EMR portal, patients across Nigeria can register at any of our network hospitals, book appointments, and access their medical records securely online.</p>
        <p>Our vision is to put patient care at the centre of everything we do &mdash; combining compassionate clinical excellence with modern digital convenience. Whether you are a first-time patient, a returning patient, a private doctor, or an external hospital, this portal is built for you.</p>
        <p>This public portal integrates directly with our <strong>Filament-based Hospital Management System</strong>, ensuring that records you create here are immediately available to the clinical teams caring for you.</p>
    </div>
</section>

<section class="futh-section futh-section--soft">
    <div class="futh-container">
        <div class="futh-services-grid">
            <div class="futh-service">
                <div class="futh-service__icon">&#129657;</div>
                <h3>Patients</h3>
                <p>Register, book appointments, view results, pay bills, and message your care team.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#129518;</div>
                <h3>Private Doctors</h3>
                <p>Register for a verified provider account and refer patients into our network.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#127973;</div>
                <h3>Hospitals</h3>
                <p>Onboard your hospital or clinic to join our referral and records network.</p>
            </div>
            <div class="futh-service">
                <div class="futh-service__icon">&#128737;</div>
                <h3>Secure &amp; Verified</h3>
                <p>All registrations are reviewed by our administration before activation.</p>
            </div>
        </div>
    </div>
</section>
@endsection
