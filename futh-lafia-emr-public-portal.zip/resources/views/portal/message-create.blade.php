@extends('portal.layout')

@section('title', 'New Message')

@section('content')
<div class="futh-auth__card" style="max-width:640px; margin:0 auto;">
    <div class="futh-auth__title"><h1>New Message</h1></div>
    <p class="futh-auth__sub">Send a non-urgent message to your hospital team. For emergencies, call your hospital directly.</p>

    @if ($errors->any())
        <div class="futh-alert futh-alert--danger">
            @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
        </div>
    @endif

    <form method="post" action="{{ route('portal.messages.store') }}" class="futh-form">
        @csrf
        <div class="futh-field">
            <label for="hospital_id">To (hospital) <span class="req">*</span></label>
            <select id="hospital_id" name="hospital_id" required>
                @foreach ($hospitals as $h)
                <option value="{{ $h->id }}">{{ $h->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="futh-field">
            <label for="subject">Subject <span class="req">*</span></label>
            <input type="text" id="subject" name="subject" value="{{ old('subject') }}" required maxlength="200">
        </div>
        <div class="futh-field">
            <label for="body">Message <span class="req">*</span></label>
            <textarea id="body" name="body" rows="6" required maxlength="5000">{{ old('body') }}</textarea>
        </div>
        <div style="display:flex; gap:0.75rem; justify-content:flex-end;">
            <a href="{{ route('portal.messages') }}" class="futh-btn futh-btn--ghost">Cancel</a>
            <button type="submit" class="futh-btn futh-btn--primary futh-btn--lg">Send message</button>
        </div>
    </form>
</div>
@endsection
