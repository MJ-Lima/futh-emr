@extends('portal.layout')

@section('title', 'Message')

@section('content')
<div class="futh-auth__card" style="max-width:760px; margin:0 auto;">
    <div class="futh-flex futh-flex--between futh-flex--center futh-mb-2">
        <h1 style="margin:0; font-size: 1.4rem;">{{ $message->subject ?: '(no subject)' }}</h1>
        <a href="{{ route('portal.messages') }}" class="futh-btn futh-btn--ghost futh-btn--sm">&larr; Back to inbox</a>
    </div>

    <dl class="futh-detail futh-mb-3">
        <dt>From</dt><dd>
            @if ($message->direction === 'inbound') You (patient)
            @else {{ $message->staffUser?->name ?: 'Hospital staff' }} ({{ $message->hospital?->name }})
            @endif
        </dd>
        <dt>Date</dt><dd>{{ $message->created_at->format('d M Y, H:i') }}</dd>
        <dt>Hospital</dt><dd>{{ $message->hospital?->name }}</dd>
        <dt>Status</dt><dd><span class="futh-badge futh-badge--gray">{{ $message->status }}</span></dd>
    </dl>

    <div class="futh-form__section" style="background:#fff;">
        <p style="white-space:pre-wrap; margin:0; line-height:1.7;">{{ $message->body }}</p>
    </div>
</div>
@endsection
