@extends('portal.layout')

@section('title', 'My Invoices')

@section('content')
<div class="futh-tabs">
    <a href="{{ route('portal.invoices') }}" class="@if (!request('status')) active @endif">All</a>
    <a href="{{ route('portal.invoices', ['status' => 'Pending']) }}" class="@if (request('status')==='Pending') active @endif">Pending</a>
    <a href="{{ route('portal.invoices', ['status' => 'Partially Paid']) }}" class="@if (request('status')==='Partially Paid') active @endif">Partially Paid</a>
    <a href="{{ route('portal.invoices', ['status' => 'Paid']) }}" class="@if (request('status')==='Paid') active @endif">Paid</a>
    <a href="{{ route('portal.invoices', ['status' => 'Overdue']) }}" class="@if (request('status')==='Overdue') active @endif">Overdue</a>
</div>

<div class="futh-panel">
    <div class="futh-panel__head"><h3>Invoices</h3></div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($invoices) > 0)
        <table class="futh-table">
            <thead><tr><th>Invoice #</th><th>Date</th><th>Items</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th></tr></thead>
            <tbody>
                @foreach ($invoices as $inv)
                <tr>
                    <td><strong>{{ $inv->invoice_number }}</strong></td>
                    <td>{{ \Carbon\Carbon::parse($inv->invoice_date)->format('d M Y') }}</td>
                    <td>{{ $inv->items->count() }}</td>
                    <td>&#8358;{{ number_format($inv->total_amount, 2) }}</td>
                    <td>&#8358;{{ number_format($inv->amount_paid, 2) }}</td>
                    <td><strong>&#8358;{{ number_format($inv->balance_due, 2) }}</strong></td>
                    <td>
                        @if ($inv->status === 'Paid') <span class="futh-badge futh-badge--green">{{ $inv->status }}</span>
                        @elseif ($inv->status === 'Overdue') <span class="futh-badge futh-badge--red">{{ $inv->status }}</span>
                        @elseif ($inv->status === 'Cancelled') <span class="futh-badge futh-badge--gray">{{ $inv->status }}</span>
                        @else <span class="futh-badge futh-badge--amber">{{ $inv->status }}</span>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="futh-table__empty">No invoices found. Visit your hospital billing desk to settle any outstanding bills.</div>
        @endif
    </div>
</div>
<div class="futh-center">{{ $invoices->links() ?? '' }}</div>
@endsection
