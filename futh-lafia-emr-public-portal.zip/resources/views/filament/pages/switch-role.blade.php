<x-filament-panels::page>
    @php
        $data = $this->getViewData();
        $roles = $data['roles'];
        $activeRole = $data['activeRole'];
    @endphp

    <div class="space-y-6">
        <div>
            <h2 class="text-xl font-bold text-gray-800">Switch Active Role</h2>
            <p class="text-sm text-gray-500 mt-1">
                You have multiple roles assigned. Your active role determines which navigation items and
                resources you see. Switching roles takes effect immediately.
            </p>
        </div>

        @if (session('success'))
            <x-filament::notification icon="heroicon-o-check-circle" color="success">
                {{ session('success') }}
            </x-filament::notification>
        @endif

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            @foreach ($roles as $role)
                <x-filament::card>
                    <div class="p-5">
                        <div class="flex items-center justify-between mb-3">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full flex items-center justify-center
                                    @if ($role->name === $activeRole)
                                        bg-green-100 text-green-700
                                    @else
                                        bg-gray-100 text-gray-500
                                    @endif">
                                    <x-filament::icon
                                        icon="@if ($role->name === $activeRole) heroicon-o-check-circle @else heroicon-o-shield-check @endif"
                                        class="w-5 h-5"
                                    />
                                </div>
                                <div>
                                    <h3 class="font-semibold text-gray-800">{{ ucfirst(str_replace('_', ' ', $role->name)) }}</h3>
                                    @if ($role->name === $activeRole)
                                        <span class="text-xs font-medium text-green-600">Currently active</span>
                                    @else
                                        <span class="text-xs text-gray-400">Click to switch</span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        @if ($role->name !== $activeRole)
                            <x-filament::button
                                wire:click="switchRole('{{ $role->name }}')"
                                color="primary"
                                size="sm"
                                icon="heroicon-o-arrows-right-left"
                            >
                                Switch to this role
                            </x-filament::button>
                        @else
                            <x-filament::button
                                disabled
                                color="success"
                                size="sm"
                                icon="heroicon-o-check"
                            >
                                Active
                            </x-filament::button>
                        @endif
                    </div>
                </x-filament::card>
            @endforeach
        </div>

        @if ($roles->count() === 1)
            <x-filament::notification icon="heroicon-o-information-circle" color="info">
                You only have one role assigned. Role switching is available when you have multiple roles.
            </x-filament::notification>
        @endif
    </div>
</x-filament-panels::page>
