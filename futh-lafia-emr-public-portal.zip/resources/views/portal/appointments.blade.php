@extends('portal.layout')

@section('title', 'My Appointments')

@section('content')
<div class="futh-panel">
    <div class="futh-panel__head">
        <h3>Appointments</h3>
        <a href="{{ route('portal.appointments.create') }}" class="futh-btn futh-btn--primary futh-btn--sm">Book new appointment</a>
    </div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($appointments) > 0)
        <table class="futh-table">
            <thead><tr><th>Reference</th><th>Date</th><th>Time</th><th>Hospital</th><th>Clinic</th><th>Provider</th><th>Status</th><th></th></tr></thead>
            <tbody>
                @foreach ($appointments as $apt)
                <tr>
                    <td><strong>{{ $apt->appointment_number }}</strong></td>
                    <td>{{ \Carbon\Carbon::parse($apt->appointment_date)->format('d M Y') }}</td>
                    <td>{{ \Carbon\Carbon::parse($apt->appointment_time)->format('H:i') }}</td>
                    <td>{{ $apt->hospital?->name }}</td>
                    <td>{{ $apt->clinic?->name }}</td>
                    <td>{{ $apt->provider?->name ?: '&mdash;' }}</td>
                    <td>
                        @if (in_array($apt->status, ['Completed'])) <span class="futh-badge futh-badge--green">{{ $apt->status }}</span>
                        @elseif (in_array($apt->status, ['Cancelled','No Show'])) <span class="futh-badge futh-badge--red">{{ $apt->status }}</span>
                        @else <span class="futh-badge futh-badge--amber">{{ $apt->status }}</span>
                        @endif
                    </td>
                    <td>
                        @if (in_array($apt->status, ['Scheduled','Confirmed']))
                        <form method="post" action="{{ route('portal.appointments.cancel', $apt) }}" style="display:inline;" onsubmit="return confirm('Cancel this appointment?');">
                            @csrf @method('delete')
                            <button class="futh-btn futh-btn--ghost futh-btn--sm" style="color:#c0392b; border-color:#fecaca;">Cancel</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="futh-table__empty">No appointments yet. <a href="{{ route('portal.appointments.create') }}">Book your first appointment</a>.</div>
        @endif
    </div>
</div>
<div class="futh-center">{{ $appointments->links() ?? '' }}</div>
@endsection
