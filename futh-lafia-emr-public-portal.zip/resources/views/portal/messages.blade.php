@extends('portal.layout')

@section('title', 'Messages')

@section('content')
<div class="futh-panel">
    <div class="futh-panel__head">
        <h3>Messages</h3>
        <a href="{{ route('portal.messages.create') }}" class="futh-btn futh-btn--primary futh-btn--sm">New message</a>
    </div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($messages) > 0)
        <table class="futh-table">
            <thead><tr><th>Date</th><th>Direction</th><th>Hospital</th><th>Subject</th><th>From/To</th><th>Status</th></tr></thead>
            <tbody>
                @foreach ($messages as $msg)
                <tr>
                    <td>{{ $msg->created_at->format('d M Y, H:i') }}</td>
                    <td>
                        @if ($msg->direction === 'inbound') <span class="futh-badge futh-badge--green">Sent by you</span>
                        @else <span class="futh-badge futh-badge--blue">Reply from hospital</span>
                        @endif
                    </td>
                    <td>{{ $msg->hospital?->name }}</td>
                    <td>
                        <a href="{{ route('portal.messages.show', $msg) }}">{{ $msg->subject ?: '(no subject)' }}</a>
                    </td>
                    <td>{{ $msg->staffUser?->name ?: '&mdash;' }}</td>
                    <td>
                        @if ($msg->direction === 'outbound' && ! $msg->read_at) <span class="futh-badge futh-badge--amber">Unread</span>
                        @else <span class="futh-badge futh-badge--gray">{{ $msg->status }}</span>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="futh-table__empty">No messages yet. <a href="{{ route('portal.messages.create') }}">Send a message</a> to your hospital.</div>
        @endif
    </div>
</div>
<div class="futh-center">{{ $messages->links() }}</div>
@endsection
