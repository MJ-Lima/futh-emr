<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>FUTH Lafia — Provider Application Approved</title>
</head>
<body style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #1f2937;">
    <div style="background: #0f5132; padding: 20px; border-radius: 8px 8px 0 0; color: #fff;">
        <h1 style="margin: 0; font-family: Georgia, serif; font-size: 22px;">FUTH Lafia EMR</h1>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.85;">Federal University Teaching Hospital, Lafia</p>
    </div>

    <div style="background: #fff; padding: 24px; border: 1px solid #e5e7eb; border-top: 0; border-radius: 0 0 8px 8px;">
        <h2 style="color: #15803d; margin-top: 0;">Your application has been approved</h2>
        <p>Dear {{ $application->applicant_name }},</p>
        <p>Good news — your {{ $accountType }} application to join the FUTH Lafia network has been approved by our administration.</p>

        <table style="width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #6b7280; width: 180px;">Application number</td><td><strong>{{ $application->application_number }}</strong></td></tr>
            <tr><td style="padding: 6px 0; color: #6b7280;">Account type</td><td>{{ $accountType }}</td></tr>
            <tr><td style="padding: 6px 0; color: #6b7280;">Login email</td><td><strong>{{ $application->email }}</strong></td></tr>
            <tr><td style="padding: 6px 0; color: #6b7280;">Status</td><td><span style="color: #15803d; font-weight: 700;">Approved</span></td></tr>
        </table>

        <p>Your provider account is now active. You can sign in with the email and password you chose during registration:</p>

        <p style="text-align: center; margin: 24px 0;">
            <a href="{{ $loginUrl }}" style="background: #0f5132; color: #fff; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: 600; display: inline-block;">Sign in to staff portal</a>
        </p>

        <p>If you did not register for this account, please reply to this email immediately so we can investigate.</p>

        <p style="margin-top: 28px; font-size: 12px; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 12px;">
            Federal University Teaching Hospital, Lafia &middot; Nasarawa State, Nigeria
        </p>
    </div>
</body>
</html>
