@extends('portal.layout')

@section('title', 'My Dashboard')

@section('content')
@if (! $patient)
    <div class="futh-alert futh-alert--warning">
        Your patient record is still being verified by our administration. Some features will become available once verification is complete.
    </div>
@else
<div class="futh-stat-grid">
    <div class="futh-stat">
        <div class="futh-stat__icon">&#128197;</div>
        <div class="futh-stat__label">Upcoming Appointments</div>
        <div class="futh-stat__value">{{ $stats['appointments'] }}</div>
        <div class="futh-stat__hint">scheduled visits</div>
    </div>
    <div class="futh-stat">
        <div class="futh-stat__icon">&#128221;</div>
        <div class="futh-stat__label">Encounters</div>
        <div class="futh-stat__value">{{ $stats['encounters'] }}</div>
        <div class="futh-stat__hint">total visits</div>
    </div>
    <div class="futh-stat">
        <div class="futh-stat__icon">&#128176;</div>
        <div class="futh-stat__label">Outstanding Invoices</div>
        <div class="futh-stat__value">{{ $stats['invoices'] }}</div>
        <div class="futh-stat__hint">awaiting payment</div>
    </div>
    <div class="futh-stat">
        <div class="futh-stat__icon">&#128172;</div>
        <div class="futh-stat__label">Unread Messages</div>
        <div class="futh-stat__value">{{ $stats['messages'] }}</div>
        <div class="futh-stat__hint">from hospital</div>
    </div>
</div>

<div style="display:grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
    <div>
        <div class="futh-panel">
            <div class="futh-panel__head">
                <h3>Upcoming Appointments</h3>
                <a href="{{ route('portal.appointments.create') }}" class="futh-btn futh-btn--primary futh-btn--sm">Book new</a>
            </div>
            <div class="futh-panel__body--flush futh-panel__body">
                @if ($upcomingAppointments->count())
                <table class="futh-table">
                    <thead><tr><th>Date</th><th>Time</th><th>Hospital</th><th>Clinic</th><th>Status</th></tr></thead>
                    <tbody>
                        @foreach ($upcomingAppointments as $apt)
                        <tr>
                            <td>{{ \Carbon\Carbon::parse($apt->appointment_date)->format('d M Y') }}</td>
                            <td>{{ \Carbon\Carbon::parse($apt->appointment_time)->format('H:i') }}</td>
                            <td>{{ $apt->hospital?->name }}</td>
                            <td>{{ $apt->clinic?->name }}</td>
                            <td><span class="futh-badge futh-badge--green">{{ $apt->status }}</span></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @else
                <div class="futh-table__empty">No upcoming appointments. <a href="{{ route('portal.appointments.create') }}">Book one now</a>.</div>
                @endif
            </div>
        </div>

        <div class="futh-panel">
            <div class="futh-panel__head"><h3>Recent Encounters</h3><a href="{{ route('portal.encounters') }}" class="futh-btn futh-btn--ghost futh-btn--sm">View all</a></div>
            <div class="futh-panel__body--flush futh-panel__body">
                @if ($recentEncounters->count())
                <table class="futh-table">
                    <thead><tr><th>Date</th><th>Hospital</th><th>Visit type</th><th>Status</th></tr></thead>
                    <tbody>
                        @foreach ($recentEncounters as $enc)
                        <tr>
                            <td>{{ \Carbon\Carbon::parse($enc->encounter_date)->format('d M Y') }}</td>
                            <td>{{ $enc->hospital?->name }}</td>
                            <td>{{ $enc->visit_type }}</td>
                            <td><span class="futh-badge futh-badge--{{ $enc->status === 'Completed' ? 'green' : 'amber' }}">{{ $enc->status }}</span></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @else
                <div class="futh-table__empty">No encounters yet.</div>
                @endif
            </div>
        </div>
    </div>

    <div>
        <div class="futh-panel">
            <div class="futh-panel__head"><h3>Recent Lab Orders</h3><a href="{{ route('portal.lab-results') }}" class="futh-btn futh-btn--ghost futh-btn--sm">All</a></div>
            <div class="futh-panel__body--flush futh-panel__body">
                @if ($recentLabOrders->count())
                <table class="futh-table">
                    <thead><tr><th>Order</th><th>Date</th><th>Status</th></tr></thead>
                    <tbody>
                        @foreach ($recentLabOrders as $lab)
                        <tr>
                            <td>{{ $lab->order_number }}</td>
                            <td>{{ \Carbon\Carbon::parse($lab->ordered_at)->format('d M Y') }}</td>
                            <td><span class="futh-badge futh-badge--{{ $lab->status === 'Verified' || $lab->status === 'Completed' ? 'green' : 'amber' }}">{{ $lab->status }}</span></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @else
                <div class="futh-table__empty">No lab orders yet.</div>
                @endif
            </div>
        </div>

        <div class="futh-panel">
            <div class="futh-panel__head"><h3>Pending Invoices</h3><a href="{{ route('portal.invoices') }}" class="futh-btn futh-btn--ghost futh-btn--sm">All</a></div>
            <div class="futh-panel__body--flush futh-panel__body">
                @if ($pendingInvoices->count())
                <table class="futh-table">
                    <thead><tr><th>Invoice</th><th>Date</th><th>Balance</th></tr></thead>
                    <tbody>
                        @foreach ($pendingInvoices as $inv)
                        <tr>
                            <td>{{ $inv->invoice_number }}</td>
                            <td>{{ \Carbon\Carbon::parse($inv->invoice_date)->format('d M Y') }}</td>
                            <td><strong>&#8358;{{ number_format($inv->balance_due, 2) }}</strong></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @else
                <div class="futh-table__empty">No pending invoices.</div>
                @endif
            </div>
        </div>
    </div>
</div>
@endif
@endsection
