<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>New staff message</title>
</head>
<body style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #1f2937;">
    <div style="background: #0f5132; padding: 20px; border-radius: 8px 8px 0 0; color: #fff;">
        <h1 style="margin: 0; font-family: Georgia, serif; font-size: 22px;">FUTH Lafia EMR</h1>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.85;">Staff messaging</p>
    </div>

    <div style="background: #fff; padding: 24px; border: 1px solid #e5e7eb; border-top: 0; border-radius: 0 0 8px 8px;">
        <h2 style="margin-top: 0;">You have a new staff message</h2>
        <p>From: <strong>{{ $staffMessage->sender?->name ?? 'Unknown' }}</strong></p>
        @if ($staffMessage->subject)
        <p>Subject: <strong>{{ $staffMessage->subject }}</strong></p>
        @endif

        <p style="background: #f8fafb; padding: 12px; border-radius: 6px; border-left: 3px solid #0f5132;">{{ Illuminate\Support\Str::limit($staffMessage->body, 280) }}</p>

        <p style="text-align: center; margin: 24px 0;">
            <a href="{{ $inboxUrl }}" style="background: #0f5132; color: #fff; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: 600; display: inline-block;">Open staff inbox</a>
        </p>

        <p style="margin-top: 28px; font-size: 12px; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 12px;">
            Federal University Teaching Hospital, Lafia
        </p>
    </div>
</body>
</html>
