<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>FUTH Lafia — Application Update</title>
</head>
<body style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #1f2937;">
    <div style="background: #0f5132; padding: 20px; border-radius: 8px 8px 0 0; color: #fff;">
        <h1 style="margin: 0; font-family: Georgia, serif; font-size: 22px;">FUTH Lafia EMR</h1>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.85;">Federal University Teaching Hospital, Lafia</p>
    </div>

    <div style="background: #fff; padding: 24px; border: 1px solid #e5e7eb; border-top: 0; border-radius: 0 0 8px 8px;">
        <h2 style="color: #991b1b; margin-top: 0;">Update on your application</h2>
        <p>Dear {{ $application->applicant_name }},</p>
        <p>Thank you for your interest in joining the FUTH Lafia network. After careful review, we are unable to approve your {{ ucfirst($application->account_type) }} application at this time.</p>

        <table style="width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #6b7280; width: 180px;">Application number</td><td><strong>{{ $application->application_number }}</strong></td></tr>
            <tr><td style="padding: 6px 0; color: #6b7280;">Status</td><td><span style="color: #991b1b; font-weight: 700;">Not approved</span></td></tr>
        </table>

        @if ($application->review_notes)
        <p><strong>Reviewer notes:</strong></p>
        <p style="background: #f8fafb; padding: 12px; border-radius: 6px; border-left: 3px solid #dc2626;">{{ $application->review_notes }}</p>
        @endif

        <p>If you believe this decision was made in error or you have additional documentation to support your application, you may re-apply at any time through our provider portal.</p>

        <p style="margin-top: 28px; font-size: 12px; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 12px;">
            Federal University Teaching Hospital, Lafia &middot; Nasarawa State, Nigeria
        </p>
    </div>
</body>
</html>
