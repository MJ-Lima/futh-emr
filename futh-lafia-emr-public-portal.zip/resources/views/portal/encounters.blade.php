@extends('portal.layout')

@section('title', 'My Encounters')

@section('content')
<div class="futh-panel">
    <div class="futh-panel__head"><h3>Encounter History</h3><span class="futh-muted" style="font-size:0.85rem;">{{ $encounters->total() ?? 0 }} records</span></div>
    <div class="futh-panel__body--flush futh-panel__body">
        @if (count($encounters) > 0)
        <table class="futh-table">
            <thead><tr><th>Date</th><th>Encounter #</th><th>Hospital</th><th>Clinic</th><th>Visit Type</th><th>Status</th></tr></thead>
            <tbody>
                @foreach ($encounters as $enc)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($enc->encounter_date)->format('d M Y') }}</td>
                    <td>{{ $enc->encounter_number }}</td>
                    <td>{{ $enc->hospital?->name }}</td>
                    <td>{{ $enc->clinic?->name }}</td>
                    <td>{{ $enc->visit_type }}</td>
                    <td><span class="futh-badge futh-badge--{{ $enc->status === 'Completed' ? 'green' : ($enc->status === 'Cancelled' ? 'red' : 'amber') }}">{{ $enc->status }}</span></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
        <div class="futh-table__empty">You have no encounter records yet. They will appear here after your first hospital visit.</div>
        @endif
    </div>
</div>

<div class="futh-center">{{ $encounters->links() ?? '' }}</div>
@endsection
