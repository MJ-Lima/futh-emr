@extends('public.layout', ['hideTopbar' => false])

@section('title', 'Patient Sign In')

@section('content')
<section class="futh-auth">
    <div class="futh-container">
        <div class="futh-auth__card">
            <div class="futh-auth__title"><h1>Patient Sign In</h1></div>
            <p class="futh-auth__sub">Access your medical records, appointments and messages.</p>

            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    @foreach ($errors->all() as $error) <div>{{ $error }}</div> @endforeach
                </div>
            @endif

            <form method="post" action="{{ route('portal.login') }}" class="futh-form">
                @csrf
                <div class="futh-field">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus>
                </div>
                <div class="futh-field">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="futh-field" style="flex-direction:row; align-items:center; gap: 0.5rem; justify-content: space-between;">
                    <label for="remember" style="font-weight:400; display:flex; align-items:center; gap:0.5rem;">
                        <input type="checkbox" id="remember" name="remember" style="width:auto;">
                        Remember me
                    </label>
                    <a href="{{ route('portal.password.request') }}" style="font-size:0.88rem;">Forgot password?</a>
                </div>
                <button type="submit" class="futh-btn futh-btn--primary futh-btn--block futh-btn--lg">Sign In</button>
            </form>

            <div class="futh-center futh-mt-3" style="font-size:0.9rem;">
                <p class="futh-muted">Not registered yet? <a href="{{ route('public.patient.register') }}">Register as a patient</a></p>
            </div>
        </div>
    </div>
</section>
@endsection
