@extends('public.layout')

@section('title', 'Patient Feedback')

@section('content')
<section class="futh-section">
    <div class="futh-container futh-container--narrow">
        <div class="futh-section__head">
            <span class="futh-eyebrow">Patient Feedback</span>
            <h2>We value your feedback</h2>
            <p>Tell us about your experience at any of our network hospitals. Your honest feedback helps us improve care for everyone.</p>
        </div>

        <div class="futh-auth__card futh-auth__card--wide" style="margin: 0 auto;">
            @if ($errors->any())
                <div class="futh-alert futh-alert--danger">
                    Please check the highlighted fields:
                    <ul>@foreach ($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
                </div>
            @endif

            <form method="post" action="{{ route('public.feedback.store') }}" class="futh-form">
                @csrf

                <div class="futh-form__section">
                    <h3>About your visit</h3>
                    <div class="futh-field">
                        <label for="hospital_id">Hospital visited <span class="req">*</span></label>
                        <select id="hospital_id" name="hospital_id" required>
                            @foreach ($hospitals as $id => $name)
                                <option value="{{ $id }}" @selected($selectedHosp === $id)>{{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="futh-grid-2">
                        <div class="futh-field">
                            <label for="department_visited">Department visited</label>
                            <input type="text" id="department_visited" name="department_visited" value="{{ old('department_visited') }}" maxlength="191" placeholder="e.g. GOP, ANC, Pharmacy">
                        </div>
                        <div class="futh-field">
                            <label for="respondent_phone">Your phone (optional)</label>
                            <input type="tel" id="respondent_phone" name="respondent_phone" value="{{ old('respondent_phone') }}" maxlength="30">
                        </div>
                    </div>
                    <div class="futh-field">
                        <label for="respondent_name">Your name (optional)</label>
                        <input type="text" id="respondent_name" name="respondent_name" value="{{ old('respondent_name') }}" maxlength="191" placeholder="Leave blank to submit anonymously">
                    </div>
                </div>

                <div class="futh-form__section">
                    <h3>Your ratings (1 = Very Poor, 5 = Excellent)</h3>
                    @php
                        $ratingFields = [
                            'rating_reception'      => 'Reception',
                            'rating_nursing_care'  => 'Nursing care',
                            'rating_doctor_care'   => 'Doctor care',
                            'rating_cleanliness'   => 'Cleanliness',
                            'rating_waiting_time'  => 'Waiting time',
                            'rating_pharmacy'      => 'Pharmacy',
                            'rating_lab_service'   => 'Lab service',
                            'rating_overall'       => 'Overall experience',
                        ];
                    @endphp
                    @foreach ($ratingFields as $field => $label)
                    <div class="futh-field">
                        <label>{{ $label }}</label>
                        <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
                            @foreach ($ratingOptions as $value => $label2)
                            <label style="display:flex; align-items:center; gap:0.35rem; padding:0.4rem 0.8rem; border:1px solid var(--futh-border); border-radius:8px; cursor:pointer; font-size:0.9rem;">
                                <input type="radio" name="{{ $field }}" value="{{ $value }}" @checked((string) old($field) === (string) $value)>
                                {{ $value }} — {{ $label2 }}
                            </label>
                            @endforeach
                        </div>
                    </div>
                    @endforeach
                </div>

                <div class="futh-form__section">
                    <h3>Tell us more</h3>
                    <div class="futh-field">
                        <label for="best_experience">What went well?</label>
                        <textarea id="best_experience" name="best_experience" rows="2" maxlength="2000">{{ old('best_experience') }}</textarea>
                    </div>
                    <div class="futh-field">
                        <label for="worst_experience">What could have been better?</label>
                        <textarea id="worst_experience" name="worst_experience" rows="2" maxlength="2000">{{ old('worst_experience') }}</textarea>
                    </div>
                    <div class="futh-field">
                        <label for="suggestions">Suggestions for improvement</label>
                        <textarea id="suggestions" name="suggestions" rows="3" maxlength="5000">{{ old('suggestions') }}</textarea>
                    </div>
                    <div class="futh-field">
                        <label for="complaints">Complaints (if any)</label>
                        <textarea id="complaints" name="complaints" rows="3" maxlength="5000">{{ old('complaints') }}</textarea>
                    </div>
                    <div class="futh-field" style="flex-direction:row; align-items:center; gap:0.5rem;">
                        <input type="checkbox" id="would_recommend" name="would_recommend" value="1" @checked(old('would_recommend')) style="width:auto;">
                        <label for="would_recommend" style="font-weight:400;">I would recommend this hospital to family and friends.</label>
                    </div>
                </div>

                <div style="display:flex; gap:0.75rem; justify-content:flex-end;">
                    <a href="{{ route('public.landing') }}" class="futh-btn futh-btn--ghost">Cancel</a>
                    <button type="submit" class="futh-btn futh-btn--primary futh-btn--lg">Submit feedback</button>
                </div>
            </form>
        </div>
    </div>
</section>
@endsection
