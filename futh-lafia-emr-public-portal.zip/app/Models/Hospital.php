<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Hospital extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name', 'code', 'status',
        'type', 'tagline', 'description',
        'address_line1', 'address_line2', 'city', 'state', 'country', 'postal_code',
        'phone_main', 'phone_alt', 'email', 'website',
        'logo_path', 'cover_path', 'latitude', 'longitude',
        'services', 'operating_hours', 'is_public', 'accepts_online_registration',
    ];

    protected $casts = [
        'status'                     => 'boolean',
        'is_public'                  => 'boolean',
        'accepts_online_registration'=> 'boolean',
        'services'                   => 'array',
        'operating_hours'            => 'array',
        'latitude'                   => 'decimal:7',
        'longitude'                  => 'decimal:7',
    ];

    /* ---- Accessors for public directory ---- */
    public function getFullAddressAttribute(): string
    {
        $parts = array_filter([
            $this->address_line1,
            $this->address_line2,
            $this->city,
            $this->state,
            $this->country,
        ]);
        return implode(', ', $parts);
    }

    public function getLogoUrlAttribute(): ?string
    {
        return $this->logo_path ? asset('storage/' . $this->logo_path) : null;
    }

    public function getCoverUrlAttribute(): ?string
    {
        return $this->cover_path ? asset('storage/' . $this->cover_path) : null;
    }

    public function scopePublic($query)
    {
        return $query->where('is_public', true)->where('status', true);
    }

    public function departments(): HasMany { return $this->hasMany(Department::class); }
    public function clinics(): HasMany { return $this->hasMany(Clinic::class); }
    public function staff(): HasMany { return $this->hasMany(Staff::class); }
    public function patients(): HasMany { return $this->hasMany(Patient::class); }
    public function users(): HasMany { return $this->hasMany(User::class); }
    public function encounters(): HasMany { return $this->hasMany(Encounter::class); }
    public function appointments(): HasMany { return $this->hasMany(Appointment::class); }
    public function insuranceProviders(): HasMany { return $this->hasMany(InsuranceProvider::class); }
    public function dutyRosters(): HasMany { return $this->hasMany(DutyRoster::class); }
    public function dutyPostings(): HasMany { return $this->hasMany(DutyPosting::class); }
    public function services(): HasMany { return $this->hasMany(Service::class); }
    public function invoices(): HasMany { return $this->hasMany(Invoice::class); }
    public function payments(): HasMany { return $this->hasMany(Payment::class); }
    public function patientPortalMessages(): HasMany { return $this->hasMany(PatientPortalMessage::class); }
    public function providerApplications(): HasMany { return $this->hasMany(ProviderApplication::class); }
}
